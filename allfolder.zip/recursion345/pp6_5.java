package linklist;
import java.util.Scanner;

	class Permutation {
		
	
	    
	     void showTeams(int arr[], int n, int r, int index,
	                                int data[], int i)
	    {
	        
	        if (index == r)
	        {
	            for (int j=0; j<r; j++)
	                System.out.print(data[j]+" ");
	            System.out.println("");
	        return;
	        }
	 
	        
	        if (i >= n)
	        return;
	 
	        
	        data[index] = arr[i];
	        showTeams(arr, n, r, index+1, data, i+1);
	 
	        
	       showTeams(arr, n, r, index, data, i+1);
	    }
	 
	    
	     void printCombination(int arr[], int n, int r)
	    {
	       	        int data[]=new int[r];
	 
	        
	        showTeams(arr, n, r, 0, data, 0);
	    }

}
	
public class pp6_5
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		
		Permutation ob = new Permutation();
		
		System.out.println("ENTER THE ARRAY SIZE");
		int size = sc.nextInt();
		
		int arr[] = new int[size];
		
		System.out.println("Enter the team size");
		int tsize = sc.nextInt();
		
		System.out.println("Enter the array elements");
		for(int i =0 ; i<size ; i++)
			arr[i] = sc.nextInt();
		
		ob.printCombination(arr, size, tsize);
		
		
		
		
	}
}
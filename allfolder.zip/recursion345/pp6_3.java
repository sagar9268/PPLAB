package linklist;

import java.util.*;

class pow
{
	
	int power(int num,int pow)
	{
	/*	if(pow>0)
		{
			return (num * power(num, pow - 1));
		}
		return 1;
	}*/
	
	int temp;
    if( pow == 0)
        return 1;
    temp = power(num, pow/2);
    if (pow%2 == 0)
        return temp*temp;
    else
        return num*temp*temp;
	}
	
}

public class pp6_3 {
	public static void main(String args[])
	{
		Scanner sc = new Scanner (System.in);
		pow ob = new pow();
		int pow,num;
		
		System.out.println("Enter the number");
		num = sc.nextInt();
		
		System.out.println("Enter the power");
		pow = sc.nextInt();
		
		int result = ob.power(num, pow);
		
		System.out.println("The value is "+result);
		
	}
	

}


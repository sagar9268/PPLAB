import java.util.*;
class qqueue
{
	int arr[],front,rear,maxsize;
public qqueue(int max)
{
	arr=new int[max];
	front=-1;
	rear=-1;
	maxsize=max;
}
public void insertleft(int x)
{
	if(front!=(rear+1)%maxsize)
	{
		if(front==-1)
		{front=0;rear=0;}
		else
		{front=(front-1+maxsize)%maxsize;}
		arr[front]=x;
		
	}
	else
	{
		System.out.println("queue is full ");
	}
}
public void deleteleft()
{
	
	if(front!=-1)
	{
		if(rear==front)
		{
			rear=-1;front=-1;
		}
		else
		{
			int t=arr[front];
			front=(front+1)%maxsize;
		}
	}
	else
	{
		System.out.println("queue is empty");

	}
}
public void insertright(int x)
{
	if(front!=(rear+1)%maxsize)
	{
		if(rear==-1)
		{front=0;rear=0;}
		else
		{rear=(rear+1)%maxsize;}
		arr[rear]=x;
	}
	else
	{
		System.out.println("queue is full");
	}
}
public void deleteright()
{
	if(rear!=-1)
	{
		if(rear==front)
		{
			rear=-1;front=-1;
		}
		else
		{
			int t=arr[rear];
			rear=(rear-1+maxsize)%maxsize;
		}
	}
	else
	{
		System.out.println("queue is empty ");
	}
}
	
public void display()
{
	int i,j,k;
	if(front<=rear)
	{
		for(i=front;i<=rear;i++)
		{
			System.out.println(arr[i]);
		}
	}
	else
	{
		for(j=0;j<=rear;j++)
		{
			System.out.println(arr[j]);
		}
		for(k=front;k<=maxsize-1;k++)
		{
			System.out.println(arr[k]);
		}
	}
	
	
	
	
}
}
public class dqueue
{
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	qqueue q1=new qqueue(10);
	
	q1.insertright(10);
	q1.insertright(20);
	q1.insertright(30);
	q1.insertleft(90);
	q1.insertleft(80);
	q1.insertleft(70);
	q1.deleteright();
	q1.deleteleft();
	//q1.deleteleft();
	q1.display();
}
}




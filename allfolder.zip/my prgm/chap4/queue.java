import java.util.*;
 class Queue
{
int a[],maxsize,rear,front;
	public 	Queue(int size)
	{
		maxsize=size;
		a=new int[maxsize];
		rear=-1;front=-1;
        }
	public void insert(int x)
	{
		if(rear!=front-1)
		{
		rear++;
		a[rear]=x;
		if(front==-1)
		front=0;
		}
		else
		{
		System.out.println("queue is full");
		}	
	}
	public void delete()
	{
	if(front!=-1)
	{
		if(rear==front)
		{
		rear=front=-1;
		}
		else
		{
		int t=a[front];
		front++;
		}
	}
     	else
	{
		System.out.println("queue is empty");
	}
	}
	public void display()
	{
	if(front<=rear)
	{
	for(int i=front;i<=rear;i++)
	{
	System.out.println(a[i]+" ");
	}
	}
	else
	{
	System.out.println("EMPTY");
	}
	}
}
public class queue
{
	public static void main(String args[])
{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the size");
	int size=sc.nextInt();
	Queue ob=new Queue(size);
 	for(int i=0;i<size;i++)
	{
	System.out.println("enter the no to insert or -1 to exit insertion");
	int n=sc.nextInt();
	if(n!=-1)
	ob.insert(n);
	else
	break;
	}
	ob.display();
	ob.delete();
	System.out.println("after deletion");
	ob.display();
}
}


	



	
	




import java.util.*;

class OrdArray
{
private long[] a;
private int nElems;

public OrdArray(int max)
{
    a=new long[max];
    nElems=0;
}

public int size()
{
	return nElems;
}

public int find(long searchKey)
{
    int lowerBound=0;
    int upperBound=nElems-1;
    int curIn;

  while(true)
    {
     curIn=(lowerBound+upperBound)/2;
     if(a[curIn]==searchKey)
        return curIn;
     else if(lowerBound > upperBound)
	return nElems; 
     else 
       {
        if(a[curIn] < searchKey)
           lowerBound = curIn + 1; 
        else
	   upperBound = curIn - 1; 
	}
    } 
}



public void insert(long value) 
{    
/*    int lowerBound=0;
    int upperBound=nElems-1;
    int curIn=0;

  while(true)
    {
     if(lowerBound > upperBound) 
        break;
    curIn=(lowerBound+upperBound)/2;
     if(value>a[curIn])
        {
	lowerBound=curIn+1;
        curIn++;
	}
    else upperBound=curIn-1;
     }
       for(int i=nElems;i>curIn;i--)
          a[i]=a[i-1];
          
          a[curIn]=value;
          nElems++;  

*/
int low=0;
int high=nElems-1;
int mid=0;
while(low<=high)
{
  mid=(low+high)/2;
 
  if(a[mid]>value)
        high=mid-1;
  else
	low=mid+1;
}

for(int k=nElems;k>low;k--)
a[k]=a[k-1];

a[low]=value;
nElems++;




     
}
public boolean delete(long value)
{
  /*
int pos=find(value)

if(pos==nElems) 
    return false;
else 
  {
    for(int k=pos; k<nElems; k++) 
    a[k] = a[k+1];
    nElems--; 
    return true;
  }
*/

    int lowerBound=0;
    int upperBound=nElems-1;
    int curIn;
    int pos;
  while(true)
    {
     curIn=(lowerBound+upperBound)/2;
     if(a[curIn]==value)
        {
	pos=curIn;
	break;
	}
     else if(lowerBound > upperBound)
	{
	pos=nElems;
	break;
	} 
     else 
       {
        if(a[curIn] < value)
           lowerBound = curIn + 1; 
        else
	   upperBound = curIn - 1; 
	} 
    }

if(pos==nElems) 
    return false;
else 
  {
    for(int k=pos; k<nElems-1; k++) 
    a[k] = a[k+1];
    nElems--; 
    return true;
  }

}

public void display() 
{
for(int j=0; j<nElems; j++) 
System.out.print(a[j] + " "); 
System.out.println("");
}

public void merge(OrdArray s1,OrdArray s2)
{
int i = 0, j = 0;
    while (i < s1.nElems && j < s2.nElems)
    {
        if (s1.a[i] < s2.a[j])
        {
            this.insert(s1.a[i]);
            i++;
        }
        else
        {
            this.insert(s2.a[j]);
            j++;
        }
    }

    while (i < s1.nElems)
    {
        this.insert(s1.a[i]);
        i++;

    }

    while (j < s2.nElems)
    {
        this.insert(s2.a[j]);
        j++;
        
    }
}
/*Another logic to implement Q 2.5 */
public OrdArray merge(OrdArray arr2)
{
int i=0;
int j=0;
OrdArray merged=new OrdArray(100);
int size1=nElems;
int size2=arr2.nElems;
int size=size1+size2-1;
a[size1]=9999;
arr2.a[size2]=9999;
for(int k=0;k<size;k++)
{
   if(a[i]<arr2.a[j])
     {
	merged.insert(a[i]);
	i++;
     }
   else 
    {
	merged.insert(arr2.a[j]);
	j++;
     }
}

}
class OrderedApp
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
/*
int maxSize;
System.out.println("Enter the size ");
maxSize=sc.nextInt();
OrdArray arr= new OrdArray(maxSize);
for(int i=0;i<maxSize;i++)
{
System.out.println("Enter the "+ (i+1) +" element");
arr.insert(sc.nextInt());
}
System.out.println("Array you entered");
arr.display(); 
System.out.println("Enter the element you want to search ");
long searchKey=sc.nextInt();

if( arr.find(searchKey) != arr.size() )
	System.out.println("Found " + searchKey);
else
	System.out.println("Can't find "+ searchKey);



System.out.println("Enter the element you want to delete ");
arr.delete(sc.nextInt());

System.out.println("Array after deletetion of the element");
arr.display(); 



*/
/*Merge 2 Sorted Arrays */
System.out.println("Enter the size ");
int size1=sc.nextInt();

System.out.println("Enter the size ");
int size2=sc.nextInt();

OrdArray s1= new OrdArray(100);
OrdArray s2= new OrdArray(100);
OrdArray des= new OrdArray(100);

System.out.println("Initialies the 1st array");
for(int i=0;i<size1;i++)
{
System.out.println("Enter the "+ (i+1) +" element");
s1.insert(sc.nextInt());
}
System.out.println("Array you entered");
s1.display(); 

System.out.println("Initialies the 2nd array");
for(int i=0;i<size2;i++)
{
System.out.println("Enter the "+ (i+1) +" element");
s2.insert(sc.nextInt());
}
System.out.println("Array you entered");
s2.display(); 

des.merge(s1,s2);
des.display();

/*Another way to implement Merge Sort */

/*
des=s1.merge(s2);
des.display();
*/
} 
}



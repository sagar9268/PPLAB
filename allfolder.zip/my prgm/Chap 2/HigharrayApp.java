import java.util.*;
class Higharray{
private int[] a;
private int n;
    Higharray(int size)
      {
	a=new int[size];
	n=0;
      }

    public void insert(int value)
	{
	  a[n]=value;
	  n++;
	}

    public boolean find(int searchkey)
	{
	int j;
	 for(j=0;j<n;j++)	
	     if(a[j]==searchkey)
	        break;
	 if(j==n)
	     return false;
	 else
	     return true;
        }

    public boolean delete(int ele)
	{
	int j;
	 for(j=0;j<n;j++)	
	     if(a[j]==ele)
	        break;
	 if(j==n)
	     return false;
	 else
	    {
	       for(int k=j;k<n-1;k++)
	       a[k]=a[k+1];
               n--;
               return true;
            }
         }

    public void display()
	{
             for(int j=0;j<n;j++)	
	     System.out.print(a[j] +" ");
	     System.out.println();
	}

    public int getMax()
	{
	     int max=0;
	     if(n==0)
			return -1;
	     else{
		     for(int i=0;i<n;i++)
		     {
	        	 if(max<a[i])
                         max=a[i];
	     	     }
	  	   return max;		
	         }

       }

     public int removeMax()
	{
	     int max=0;
		if(n==0)
			return -1;
		else{
			for(int j=0;j<n;j++)
			{
				if(max<a[j])
				max=a[j];
			}
			if(this.delete(max))
   				return max;
			else
                     return -1;
                    }
				
	}

      /*
	public void noDup()
	{
 	     for(int j=0;j<n;j++)
	          for(int i=j+1;i<n;i++)	
	              if(a[j]==a[i])
                         {
	   	          for(int k=i;k<n-1;k++)
 			     a[k]=a[k+1];
			      n--;
			      j--;	
 			 }
         }
	*/
	public void noDup()
	{
 	     for(int j=0;j<n;j++)
	          for(int i=j+1;i<n;i++)	
	              if(a[j]==a[i])
                         {
			  a[j]=-100;
 			 }
   	        	   
 	     for(int j=0;j<n;j++)
		if(a[j]==-100)
		   {
		     for(int k=j;k<n-1;k++)
 		     a[k]=a[k+1];
		     n--;
	             j--;
                   }
         }
}

class HigharrayApp{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);

System.out.println("Enter the size of the array");
int size=sc.nextInt(); 

Higharray arr= new Higharray(size); 

for(int i=0;i<size;i++)
   {
        System.out.println("Enter the value at the index "+ (i+1));
	arr.insert(sc.nextInt()); 
   }  

System.out.println("The array you have entered is");
arr.display(); 

/*
System.out.println("Enter the value you want to search");
int searchkey=sc.nextInt(); 

if( arr.find(searchkey) )
	System.out.println("Found "+ searchkey);
else
	System.out.println("Can�t find " + searchkey);


System.out.println("Enter the value you want to delete");
searchkey=sc.nextInt(); 


if(arr.delete(searchkey))
	System.out.println("Deleted value " + searchkey);
else
	System.out.println("Value "+ searchkey + " Not Found Error in Deletion");


arr.display(); 

int max=arr.removeMax();
if(max==-1)
	System.out.println("No data in the array");
else
	System.out.println("Max element of the array is " +max);

System.out.println("The array after deleting the max element");
arr.display(); 
*/

Higharray ins= new Higharray(size); 
int x=arr.removeMax();
	while(x!=-1)
	{
	ins.insert(x); 
	x=arr.removeMax();	
	}

System.out.println("The array after inverse sorting");
ins.display(); 

ins.noDup();
System.out.println("The array after deleting the duplicate values");
ins.display(); 
}}
import java.util.Scanner;
class ArrayIns{


        int a[];

        int n;

        public ArrayIns(int maxIndex)
        {

                a=new int[maxIndex];
                n=0;
        }
	public void insert(int val)
	{
		a[n]=val;
		n++;
	}

        public void display()
        {
		int i;
		for(i=0;i<n;i++)
			System.out.print(a[i]+ " ");
		System.out.println(" ");
	}

	public void insertionsort()
	{
/*--------Original InsertionSort--------*/
/*	int i,j;
	for(i=1;i<n;i++)
	  {
	   int temp=a[i];
	   j=i;
	   while(j>0 && a[j-1]>=temp)
	   {
	   a[j]=a[j-1];
	   j--;
	   }
	   a[j]=temp;
	  }
*/
/*--------3.6--------*/
	int i,j,count=0;
	for(i=1;i<n;i++)
	  {
	    int temp=a[i];
	    j=i;
	    while(j>0 && a[j-1]>=temp)
	     {
	       if(a[j-1]==temp && temp!=-1)
                 {
		    temp=-1;
		    count++;
	         }
	       a[j]=a[j-1];
	        j--;
	      }
	     a[j]=temp;
	  }
	for(int loop=0;loop<n;loop++)
           a[loop]=a[loop+count];

        n=n-(count);


/*--------3.5--------*/
/*	int i,j,copy=0,comp=0;
	for(i=1;i<n;i++)
	  {
	   int temp=a[i];
	   j=i;
	   while(j>0)  
	   {  
	      comp++;
	      if(a[j-1]>=temp)
            {
		      a[j]=a[j-1];
              j--;
            }
           else
             break;
	   }
	    a[j]=temp;
        copy++;

	  }
      System.out.println("Number of Copies :"+copy+"\nNumber of Comparisions :"+comp);
*/ }
	public void swap(int in,int out)
	{
        int temp=a[in];
        a[in]=a[out];
        a[out]=temp;
	}

/*--------3.2--------*/
	public int median()
	{
	if(n%2==0)
	return (a[(n/2)-1]+a[n/2])/2;
	else
	return a[n/2];
	}
/*--------3.3--------*/
        public void noDups()
        {
 	    int i=0,j=0;
 	    for(j=0;j<n;j++)
	       {
	         if(a[i]!=a[j])
        	  {
		   a[i+1]=a[j];
	           i++;
		  }
               }n=i+1;
        }
/*--------3.4--------*/
	public void oddevensort()
	{
	int j=0,k=0,flag=1;
        while(flag!=0)
	      {
	         flag=0;
	         for(int i=n-1;i>n/2;i--)
	            {
	   			   for(j=0;j<i;j=j+2)
	      			  if(a[j]>a[j+1])
	                    { 
		                  swap(j,j+1);
		                  flag++;
	                    }
	               for(k=1;k<i;k=k+2)
	                  if(a[k]>a[k+1])
	                    {
		                  swap(k,k+1);
		                  flag++;
       	                }
	             }
	
            }
	}
}

public class InsertionSort{
	public static void main(String args[]){
		
		int i,arrlength,maximum;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array");
		arrlength=sc.nextInt();
		ArrayIns arr;
		arr=new ArrayIns(100);
		System.out.println("Enter "+arrlength+" elements in array");
		for(i=0;i<arrlength;i++)
			arr.insert(sc.nextInt());

		System.out.println("The elements Entered are:");
		arr.display();
		arr.insertionsort();		
		//arr.oddevensort();
		System.out.println("After Sorting:");
		arr.display();
		//System.out.println("Median is "+ arr.median());
	        //arr.noDups();
		//System.out.println("After removing duplicate elements from the array");
		//arr.display();
}
}


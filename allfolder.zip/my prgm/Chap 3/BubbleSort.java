import java.util.*;
class ArrayBub
{
   private long[] a;
   private int nElems; 

  public ArrayBub(int max) 
  {
     a = new long[max]; 
     nElems = 0; 
  }

  public void insert(long value) 
  {
     a[nElems] = value; 
     nElems++; 
   }

   public void display() 
   {
      for(int j=0; j<nElems; j++) 
         System.out.print(a[j] + " ");
 
      System.out.println();
   }

   public void bubbleSort()
   {

      int i,j,k,l=0;
      for(i=nElems-1;i>l;i--,l++)
        {
	   for(j=0; j<i ; j++) 
               if( a[j] > a[j+1] ) 
                  swap(j, j+1); 
           for(k=i; k>l; k--) 
               if( a[k] < a[k-1] ) 
                  swap(k, k-1); 

        }
   }

   private void swap(int one, int two)
   {
      long temp = a[one];
      a[one] = a[two];
      a[two] = temp;
   }

}

class BubbleSort
{
   public static void main(String[] args)
   {
    Scanner sc=new Scanner(System.in);
    int maxSize = 100;
    ArrayBub arr; 
    arr = new ArrayBub(maxSize); 
    System.out.println("Enter the size of the array");
    int size=sc.nextInt();
    System.out.println("Enter "+size+" elements");
    for(int i=0;i<size;i++)
      arr.insert(sc.nextInt());
    arr.display(); 
    arr.bubbleSort();
    arr.display();
    }
} 
import java.util.Scanner;
class ArrayBub{


        int a[];

        int n;

        public ArrayBub(int maxIndex)
        {

                a=new int[maxIndex];
                n=0;
        }
	public void insert(int val)
	{
		a[n]=val;
		n++;
	}

        public void display()
        {
		int i;
		for(i=0;i<n;i++)
			System.out.print(a[i]+ " ");
		System.out.println(" ");
	}

	public void oddevensort()
	{
	/*
	int j=0,k=0;
	for(int i=n-1;i>=0;i--)
	{
	   for(j=0;j<=i;j=j+2)
	      if(a[j]>a[j+1])
	        swap(j,j+1);
	        
	   for(k=1;k<=i;k=k+2)
	      if(a[k]>a[k+1])
	        swap(k,k+1);
	}
	*/
	      int i,j,flg=1;
	for(int j=0;j<n;j++)
//        while(flg!=0)
        {
           flg=0;

           for(i=1;i<nelems-2;i+=2)
              for(j=0; j<nelems-i-1; j++)
                 if(a[j] > a[j+1])
                   {
                    swap(j,j+1);
			    flg++;
		        }

           for(i=0;i<nelems-2;i+=2)
               for(j=0; j<nelems-i-1; j++)
                  if(a[j] > a[j+1])
			   {
                      swap(j,j+1); 
			      flg++;
			   }
         }



  
	}
	public void swap(int in,int out)
	{
        int temp=a[in];
        a[in]=a[out];
        a[out]=temp;
	}
    }


public class OddEvenSort{
	public static void main(String args[]){
		
		int i,arrlength,maximum;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array");
		arrlength=sc.nextInt();
		ArrayBub arr;
		arr=new ArrayBub(100);
		System.out.println("Enter "+arrlength+" elements in array");
		for(i=0;i<arrlength;i++)
			arr.insert(sc.nextInt());

		System.out.println("The elements Entered are:");
		arr.display();
		arr.oddevensort();
		System.out.println("After Sorting:");
		arr.display();

}
}


import java.util.Scanner;
class ArraySel{


        int a[];

        int n;

        public ArraySel(int maxIndex)
        {

                a=new int[maxIndex];
                n=0;
        }
	public void insert(int val)
	{
		a[n]=val;
		n++;
	}

        public void display()
        {
		int i;
		for(i=0;i<n;i++)
			System.out.print(a[i]+ " ");
		System.out.println(" ");
	}

	public void selectionsort()
	{
	int min=0;
	for(int i=0;i<n-1;i++)
	  {
	   min=i;
	   for(int j=i+1;j<n;j++)
	      if(a[j]<a[min])
	        min=j;
	   swap(i,min);
	      
	  }
	}
	public void swap(int in,int out)
	{
        int temp=a[in];
        a[in]=a[out];
        a[out]=temp;
	}
    }


public class SelectionSort{
	public static void main(String args[]){
		
		int i,arrlength,maximum;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of array");
		arrlength=sc.nextInt();
		ArraySel arr;
		arr=new ArraySel(10);
		System.out.println("Enter "+arrlength+" elements in array");
		for(i=0;i<arrlength;i++)
			arr.insert(sc.nextInt());

		System.out.println("The elements Entered are:");
		arr.display();
		arr.selectionsort();
		System.out.println("After Sorting:");
		arr.display();

}
}


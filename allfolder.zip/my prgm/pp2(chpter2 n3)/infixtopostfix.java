import java.util.*;
class stack
{
	char arr[];
	int top;
	int maxsize;
	public stack(int max)
	{
		maxsize=max;
		arr=new char[maxsize];
		top=-1;
	}
	public void push(char ch)
	{
		if(top!=maxsize-1)
		{	top++;
			arr[top]=ch;
		}
		else
		System.out.println("stack is full");
	}
	public char pop()
	{
		if(top!=-1)
		{
			char c=arr[top];
			top--;
			return(c);
		}
		else 
		{	System.out.println("stack is empty");
			return('@');
		}
	}
/*	public void display()
	{
		for(int i=top;i>=0;i--)
		{
			System.out.println(arr[i]);
		}
	}*/
}
public class infixtopostfix
{
	public static boolean highprecedence(char ch,char ch1)
	{
		if((ch=='*'||ch=='/'||ch=='%')&&(ch1=='+'||ch1=='-'))
			return(true);
		else if((ch=='+'||ch=='-')&&(ch1=='+'||ch1=='-'))
			return(true);
		else
			return(false);
	}
	public static void main(String[] args)
	{
		String infix;
		String postfix="";
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		infix=sc.nextLine();
		int l=infix.length();
		stack s1=new stack(l);
		for(int i=0;i<l;i++)
		{
			char ch1=infix.charAt(i);
			
			if(ch1=='(')
			{
				s1.push(ch1);
			}
			else if(ch1==')')
			{
				char c=s1.pop();
				while(c!='(')
				{
					postfix=postfix+c;
					c=s1.pop();
				}
			}
			else if(ch1=='+'||ch1=='-'||ch1=='*'||ch1=='/'||ch1=='%')
			{
				if(s1.top==-1)
				s1.push(ch1);
				else
				{
					while(s1.top!=-1)
					{
						char ch=s1.pop();
						if(ch=='(')
						{
							s1.push(ch);
							break;
						}
						else if(ch=='+'||ch=='-'||ch=='*'||ch=='/'||ch=='%')
						{
							if(highprecedence(ch,ch1))
							postfix=postfix+ch;
							else{
							s1.push(ch);
							break;}
						}
					}
						s1.push(ch1);
					
				}
			}
			else postfix=postfix+ch1;
		}
			while(s1.top!=-1)
			{
				char ch=s1.pop();
				postfix=postfix+ch;
			}
		

		
	System.out.println("the final postfix expression is" +postfix);
}
}		

			

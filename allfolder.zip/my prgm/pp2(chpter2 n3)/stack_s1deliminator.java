import java.util.Scanner;
class stack
{
        char arr[];
        int top,maxsize;
public stack(int max)
{
        arr=new char[max];
        top=-1;
        maxsize=max;
}
public void push(char c)
{
        if(top!=maxsize-1)
        {
                top++;
                arr[top]=c;
        }
        else
                System.out.println("stack is full");
}
public char pop()
{
        if(top!=-1)
        {
                char c=arr[top];
                top--;
                return(c);
        }
        else
        { 
		System.out.println("stack is empty");
		return('/');
	}
        
}
public void display()
{
        for(int i=top;i>=0;i--)
        System.out.println(arr[i]);
}
}
public class stack_s1
{
public static void main(String[] args)
{
        Scanner sc=new Scanner(System.in);
        stack s1=new stack(5);
        String str;
        char ch,ch1;
	int i;
	System.out.println("enter the string");
        str=sc.next();
        int l=str.length();
        for(i=0;i<l;i++)
        {
        	 ch=str.charAt(i);
		switch(ch) 
		{
			case '[':
			case '{':
			case '(':
			s1.push(ch);
			break;
			case ']':
			case '}':
			case ')':
			if(s1.top!=-1) 
			{
			ch1=s1.pop();
   		

			//if(s1.top!=-1)
			//System.out.println("error / extra closing delimeter at"+i);
			if(ch1=='{' && ch!='}' || ch1=='[' && ch!=']' || ch1=='(' && ch!=')')
			System.out.println("error /unmatched delimeter at"+i);}
		else 
{ 
System.out.println("error / extra closing delimeter at "+i);}
break;
	}}
	if(s1.top!=-1)
	System.out.println("error / extra opening delimeters at"+(i-1));
}
}
     
        
        

                                              


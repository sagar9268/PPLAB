import java.util.Scanner;
class array
	{
	int arr[],nele;
	public array(int size)
	{
	arr=new int[size];
	nele=0;
	}
	public void insert(int x)
	{
	arr[nele]=x;
	nele++;
	}
	public void bsort()
	{       int out,j;
		for( j=nele-1;j>0;j--)
		{
                                     
			for(int i=0;i<j;i++)
			{   
				if(arr[i]>arr[i+1])
					{
						int t=arr[i];
						arr[i]=arr[i+1];
						arr[i+1]=t;
					}
			}}}
public void bdsort()
	
	{       int out,j;
		for( j=nele-1,out=0;out<j;j--,out++)
		{
                                     
			for(int i=0;i<j;i++)
			{
				if(arr[i]>arr[i+1])
					{
						int t=arr[i];
						arr[i]=arr[i+1];
						arr[i+1]=t;

					}
			}
		display();


			for(int i=j-1;i>out;i--)
				{
				if(arr[i]<arr[i-1])
				{
				int m=arr[i];
				arr[i]=arr[i-1];
				arr[i-1]=m;
}
}display();
		}
	}
public void oddevensort()
{
 int j;
                for(j=nele-1;j>0;j--)
                        {
                        for(int i=0;i<nele-1;i=i+2)
                        {
                                if(arr[i]>arr[i+1])
                                {
                                        int t=arr[i];
                                        arr[i]=arr[i+1];
                                        arr[i+1]=t;
                                        }
                        }
                        for(int k=1;k<nele-1;k=k+2)
                                {
                                        if(arr[k]>arr[k+1])
                                {
                                int m=arr[k];
                                arr[k]=arr[k+1];
                                arr[k+1]=m;
}
}
}
}
	public void display()
	{
	for(int i=0;i<nele;i++)
	System.out.println(arr[i]);
}
	public double median()
	{
	if(nele%2==0)
         return((arr[nele/2]+arr[nele/2]-1)/2.0);
	else
	return((double)arr[nele/2]);
}
public void insort()
{int count1=0,count2=0;
for(int out=1;out<nele;out++)
{
int t=arr[out];
int in=out;
while(in>0)
{
count1++;
if(arr[in-1]>t)
{
arr[in]=arr[in-1];
in--;
count2++;
}
else
break;
arr[in]=t;
}
}
display();
System.out.println("no of comparison="+count1);
System.out.println("no. of shifting="+count2);
}}
class bubbleArray
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the size of array");
int n=sc.nextInt();
array ob=new array(n);
for(int i=0;i<n;i++)
{
System.out.println("enter");
int k=sc.nextInt();
ob.insert(k);
}
ob.display();
//ob.bsort();
//ob.bdsort();
//ob.oddevensort();

System.out.println("sorted array");
ob.insort();
//ob.display();
//double s=ob.median();
//System.out.println("median ="+s);
}
}




import java.util.*;
class node
{
	private int data1;
	node left,right;
	public node(int x)
	{
		data1=x;
	}
	int getdata()
	{
		return(data1);
	}
}
class bst
{
	node root;
	public bst()
	{
		root=null;
	}
	void insert()
	{
		node temp,parent;
		System.out.println("Enter the number to be inserted ");
		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		node new1=new node(x);
		if(root==null)
		{
			root=new1;
		}
		else
		{
			temp=root;
			while(true)
			{
				parent=temp;
				if(x<temp.getdata())
				{
					temp=temp.left;
					if(temp==null)
					{
						parent.left=new1;break;
					}
				}
				else
				{
					temp=temp.right;
					if(temp==null)
					{
						parent.right=new1;break;
					}
				}
				
			}
		}
	}
	void preorder(node n)
	{
		if(n!=null)
		{
			System.out.println(n.getdata());
			preorder(n.left);
			preorder(n.right);
		}
		else
			return;
	}
	node search(int x)
	{
		node temp=root;
		while(temp.getdata()!=x)
		{
			if(x>temp.getdata())
			temp=temp.right;
			else
			temp=temp.left;
			if(temp==null)
			return(null);
		}
			return(temp);
	}
	boolean delete(int key)
	{
		node current=root;
		node parent=root;
		boolean isleft=true;
		while(current.getdata()!=key)
		{
			parent=current;
			if(key<current.getdata())
			{
				isleft=true;
				current=current.left;
			}
			else
			{
				isleft=false;
				current=current.right;
			}
			if(current==null)
				return false;
		}
		if(current.left==null && current.right==null)
		{
			if(current==root)
			root=null;
			else if(isleft)
			parent.left=null;
			else
			parent.right=null;
		}
		else if(current.right==null)
		{
			if(current==root)
			root=current.left;
			else if(isleft)
			parent.left=current.left;
			else
			parent.right=current.left;
		}
		else if(current.left==null)
		{
			if(current==root)
			root=current.right;
			else if(isleft)
			parent.left=current.right;
			else
			parent.right=current.right;
		}
		else
		{
			node successor=getsuccessor(current);
			if(current==root)
			root=successor;
			else if(isleft)
			parent.left=successor;
			else
			parent.right=successor;
			successor.left=current.left;
		}
		return true;
}
	node getsuccessor(node delnode)
	{
		node successorparent=delnode;
		node successor=delnode;
		node current1=delnode.right;
		while(current1!=null)
		{
			successorparent=successor;
			successor=current1;
			current1=current1.left;
		}
		if(successor!=delnode.right)
		{
			successorparent.left=successor.right;
			successor.right=delnode.right;
		}
			return successor;
	}
}
 public class tree
{
	public static void main(String[] args)
	{
		bst b1=new bst();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.insert();
		b1.preorder(b1.root);
		//node n=b1.search(1000);
		//if(n!=null)
		//System.out.println("element found");
		//else
		//System.out.println("element not present");
		b1.delete(150);
		b1.preorder(b1.root);
	
	}
}

import java.util.Scanner;
class higharray1
{
long a[];
int nele,s=0;
public higharray1(int size)
{
a=new long[size];
nele=0;
}

public int bsearch(long ele)
{
 int flag=0;
int u=nele;
int l=0;
int m;
while(l<=u)
{
m=(l+u)/2;
if(a[m]==ele)
{
flag=1;
break;
}
else if(ele>a[m])
l=m+1;
else
u=m-1;
}
return flag;
}

public void insert(long value)
{
int i,j;
for(i=0;i<nele;i++)
{
if(a[i]>value)
break;
}
for(j=nele-1;j>=i;j--)
a[j+1]=a[j];

a[i]=value;

//a[nele]=value;
nele++;



}
public void display()
{
for(int j=0;j<nele;j++)
System.out.print(a[j]+" ");
System.out.println("");
}

}
class orderarray
{
public static void main(String args[])
{
higharray1 arr=new higharray1(5);
Scanner sc=new Scanner(System.in);
for(int j=0;j<5;j++)
{
System.out.println("enter the array element");
long n=sc.nextLong();
arr.insert(n);
}
arr.display();
int k=arr.bsearch(20);
if(k==1)
System.out.println("found");
else if(k==0)
System.out.println("not found");
//int searchkey=10;
//if(arr.find(searchkey))
//System.out.println("found");
//else 
//System.out.println("not found");
//long s=arr.getmax();
//System.out.println("the max of array is "+s);
//int s=arr.duplicate();
//for(int i=1;i<=s;i++)
//{
//arr.delete(-1);
//}
//if(t==0)
//System.out.println("number not present");
//else 
//System.out.println("array after deletion");
//arr.display();
}
}






import java.util.*;
class queue
{
	int arr[],nele,maxsize;
	public queue(int max)
	{
		
		nele=0;
		maxsize=max;
		arr=new int[maxsize];
	}
	public void insert(int x)
	{
		int j;
		if(nele==0)
		{
			arr[nele]=x;
			nele++;
		}
		else
		{
			for(j=nele-1;j>=0;j--)
			{
				if(x>arr[j])
				arr[j+1]=arr[j];
				else
				break;
			}
			arr[j+1]=x;
			nele++;
		}
	}
	public void delete()
	{
		int t=arr[nele-1];
		nele--;
		System.out.println(t+"is deleted");
	}
	public void display()
	{
		for(int i=0;i<nele;i++)
		{
			System.out.println(arr[i]);
		}
	}
}
public class priorityqueue
{
	public static void main(String[] args)
	{
		queue q1=new queue(5);
		Scanner sc=new Scanner(System.in);
		System.out.println(" ENTER");
		for(int i=0;i<5;i++)
		{
			int n=sc.nextInt();
			q1.insert(n);
		}
		System.out.println();
		q1.delete();
		System.out.println();
		q1.display();
	}
}
	


import java.util.*;
class node
{
	int x;
	node next;
	node prev;
 	public node(int y)
	{
		x=y;
	}
	void display()
	{
		System.out.println(x);
	}
}
class linkedlist
{
	node start,temp,temp1,current;
	/*void create()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of the node to be created");
		int x=sc.nextInt();
		node new1=new node(x);
			if(start==null)
			{
				start=new1;
				temp=new1;
			}
			else
			{
				temp.next=new1;
				new1.prev=temp;
				temp=new1;
			}
		
	}
	void insert_at_end()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of the node to be inserted at the end");
		int x=sc.nextInt();
		node new1=new node(x);
		temp=start;
		while(temp.next!=null)
		{
			
			temp=temp.next;	
			
		}
		temp.next=new1;
		new1.prev=temp;
		new1.next=null;
	}
	void insert_at_beg()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of the node to be inserted at the begining");
		int x=sc.nextInt();
		node new1=new node(x);
		new1.next=start;
		start.prev=new1;
		start=new1;
	}
	void delete_from_beg()
	{
		temp1=start;
		start.next.prev=null;
		start=start.next;
		System.out.println(temp1.x+"is deleted");
	}
	void display1()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.println(temp.x);
			temp=temp.next;
		}
	}*/
	void current_node_insertion()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value");
		int x=sc.nextInt();
		node new1=new node(x);
		if(current==null)
		{
			current=new1;;
			new1.next=current;
		}
		else
		{
			new1.next=current.next;
			current.next=new1;
			current=new1;
		}
	}
	void display2()
	{
		temp=current;
		do
		{
			temp.display();
			temp=temp.next;
		}
		while(temp!=current);
	}
		
	
	
}
class double_linkedlist
{	
	public static void main(String[] args)
	{
		linkedlist l1=new linkedlist();
		l1.current_node_insertion();
		l1.current_node_insertion();
		l1.current_node_insertion();
		l1.display2();
		/*l1.insert_at_beg();
		l1.insert_at_end();
		l1.delete_from_beg();
		l1.display();*/
	}
}

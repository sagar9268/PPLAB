import java.util.Scanner;
class higharray1
{
long a[];
int nele,s=0;
public higharray1(int size)
{
a=new long[size];
nele=0;
}
public boolean find(long searchkey)
{
int j;
for(j=0;j<nele;j++)
if(a[j]==searchkey)
break;
if(j==nele)
return false;
else 
return true;
}
public void insert(long value)
{
a[nele]=value;
nele++;
}
public int delete(long value)
{
int j;
for(j=0;j<nele;j++)
if(value==a[j])
break;
if(j==nele)
return 0;
else 
{
for(int k=j;k<nele-1;k++)
a[k]=a[k+1];
nele--;
return 1;
}
}
public void display()
{
for(int j=0;j<nele;j++)
System.out.print(a[j]+" ");
System.out.println("");
}
public long getmax()
{
long max=-1;
for(int j=0;j<nele;j++)
{
if(a[j]>max)
max=a[j];
}
return max;
}

public int duplicate()
{
for(int i=0;i<nele-1;i++)
{
for(int j=i+1;j<nele;j++)
{
if(a[i]==a[j])
{
a[j]=-1;
s++;
}
}
}
return s;
//for(int i=0;i<nele;i++)
//{
//delete(-1);
//}
}
}
class higharray
{
public static void main(String args[])
{
higharray1 arr=new higharray1(5);
Scanner sc=new Scanner(System.in);
for(int j=0;j<5;j++)
{
System.out.println("enter the array element");
long n=sc.nextLong();
arr.insert(n);
}
arr.display();
//int searchkey=10;
//if(arr.find(searchkey))
//System.out.println("found");
//else 
//System.out.println("not found");
//long s=arr.getmax();
//System.out.println("the max of array is "+s);
int s=arr.duplicate();
for(int i=1;i<=s;i++)
{
arr.delete(-1);
}
//if(t==0)
//System.out.println("number not present");
//else 
//System.out.println("array after deletion");
arr.display();
}
}






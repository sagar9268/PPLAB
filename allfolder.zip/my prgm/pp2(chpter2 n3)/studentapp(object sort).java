import java.util.Scanner;
 class student
{
	private double mark;
	private String name;
	public student(String n1,double m1)
	{
		mark=m1;
		name=n1;
	}
        public void displaym()
	{
	System.out.println(name + " "+ mark);
	
	}
	public String getName()
        {
		return(name);
	}
	public double getmark()
	{
		return(mark);
	}
}

 class studentarray
{
	int nele;
	student arr[];
	public studentarray(int maxsize)
	{
		arr=new student[maxsize];
		nele=0;
	}
	public void display()
	{
		for(int i=0;i<nele;i++)
		arr[i].displaym();
	}
	public void insert(String s,double m)
	{
		student s1=new student(s,m);
		arr[nele]=s1;
		nele++;
	}
	public void search(String nm)
	{
		int flag=0,pos=0;
		for(int i=0;i<nele;i++)
		{
			if(nm.compareTo(arr[i].getName())==0)
			flag=1;
			pos=i;
			break;
		}
	System.out.println("the name is "+arr[pos].getName());
	System.out.println("the mark is "+arr[pos].getmark());
	}
	public void objectsort()
	{
		int j,i;
		for(j=nele-1;j>0;j--)
		{
			for(i=0;i<j;i++)
			{
				if(arr[i].getName().compareTo(arr[i+1].getName())>0)
				{
					student t=arr[i];
					arr[i]=arr[i+1];
					arr[i+1]=t;
				}
			}
		}
	}
		

}

public class studentapp
{
	public static void main(String args[])
	{
		studentarray s2=new studentarray(5);
		s2.insert("shreeja",100);
		s2.insert("a",90);
		s2.insert("b",92);
		s2.insert("kshitij",95);
		s2.insert("c",89);
		//s2.insert("d",55);
		s2.display();
		s2.objectsort();
		s2.display();
		//s2.search("shreeja");
	}
}

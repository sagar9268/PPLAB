import java.util.Scanner;
class array
	{
	int arr[],nele;
	public array(int size)
	{
	arr=new int[size];
	nele=0;
	}
	public void insert(int x)
	{
	arr[nele]=x;
	nele++;
	}
	public void bsort()
	{
		for(int j=nele-1;j>0;j--)
		{
			for(int i=0;i<j;i++)
			{
				if(arr[i]>arr[i+1])
					{
						int t=arr[i];
						arr[i]=arr[i+1];
						arr[i+1]=t;
					}
			}
		}
	}
	public void display()
	{
	for(int i=0;i<nele;i++)
	System.out.println(arr[i]);
}
}
class bubbleArray
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the size of array");
int n=sc.nextInt();
array ob=new array(n);
for(int i=0;i<n;i++)
{
System.out.println("enter");
int k=sc.nextInt();
ob.insert(k);
}
ob.display();
ob.bsort();
System.out.println("sorted array");
ob.display();
}
}




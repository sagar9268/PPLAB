import java.util.*;
class node
{
	private int data1;
	private double data2;
	node next;
	
	public node(int x,double y)
	{
		data1=x;
		data2=y;
		next=null;
	}
	public void display()
	{
		System.out.println(data1+" "+data2);
	}
	public int getdata()
	{
		return(data1);
	}
}
class llist
{
	node start,temp;
	void display()
	{
		temp=start;
		do
		{
			temp.display();
			temp=temp.next;
		}while(temp!=start);
	}
	void create()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("press 1: to create a new node otherwise press 2");
		int a=sc.nextInt();
		while(a==1)
		{
			System.out.println("enter the value of x:");
			int x=sc.nextInt();
			System.out.println("enter the value of y:");
			double y=sc.nextDouble();
			node new1=new node(x,y);
			if(start==null)
			{
				start=new1;
				temp=new1;
				new1.next=start;
			}
			else
			{
				temp.next=new1;
				new1.next=start;
				temp=new1;
			}
			System.out.println("if you want to continue creating the new node then press 1:");
			 a=sc.nextInt();
		}
         }
	/*void insert_at_beg()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of x to insert at the beginning");
		int x=sc.nextInt();
		System.out.println("enter the value of y to insert at the biginning");
		double y=sc.nextDouble();
		node new2=new node(x,y);
		new2.next=start;
		start=new2;
	}	
	void delete_from_beg()
	{
		node t=null;
		if(start==null)
		System.out.println("linked list is empty");
		else
		{
			t=start;
		        start=start.next;
		}
		System.out.println("the deleted node is :");
		t.display();	
	}
	void search(int x)
	{
		node temp=start;
		while(temp!=null)
		{
			if(x==temp.getdata())
			break;
			temp=temp.next;
		}
		if(temp==null)
		System.out.println(x+ "is not found");
		else
		System.out.println(x+ "is found");


	}
	void delete_at_any_pos(int x)
	{
		node temp=start;
		node temp1=null;
		while(temp!=null)
		{
			if(temp.getdata()==x)
			
			break;
			temp1=temp;
			temp=temp.next;
		}
			if(temp==null)
			System.out.println(x+ "is not present");
			else if(temp1==null)
			start=start.next;
			else
			temp1.next=temp.next;
	}
	void insert_at_any_pos()
	{
		int i=0,ctr=0,pos,x;
		double y;
		node temp=start;
		node temp1=null;
		while(temp!=null)
		{
			ctr++;
			temp=temp.next;
		}
		System.out.println("enter the position");
		Scanner sc=new Scanner(System.in);
		pos=sc.nextInt();
		if(pos==1)
		insert_at_beg();
		else if(pos<=ctr)
		{	
			System.out.println("enter the value of x");
			x=sc.nextInt();
			System.out.println("enter the value of y");
			y=sc.nextDouble();
			node n4=new node(x,y);
			temp=start;
			while(i<pos-2)
			{
				temp1=temp.next.next;
				temp=temp.next;
				i++;
			}
			temp.next=n4;
			n4.next=temp1;
		}
		else
		System.out.println("the entered position is invalid");
	
			
	}
	void delete_from_end()
	{
		node temp=start;
		node temp1=null;
		while(temp.next!=null)
		{
			temp1=temp;
			temp=temp.next;
		}
		temp1.next=null;
	}*/
}

public class circularlinkedlist
{
	public static void main(String[] args)
	{
		llist l1=new llist();
		l1.create();
		l1.display();
		/*l1.insert_at_beg();
		System.out.println(" ");
		l1.display();
		l1.delete_from_beg();
		System.out.println(" ");
		l1.display();
		l1.search(10);
        	l1.delete_at_any_pos(10);
		System.out.println("  after deletion from any position ");
		l1.display();
		l1.insert_at_any_pos();
		l1.delete_from_end();
		l1.display();*/
		
	}  


}

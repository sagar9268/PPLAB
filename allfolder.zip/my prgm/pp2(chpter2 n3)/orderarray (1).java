import java.util.Scanner;
class higharray1
	{
		long a[];
		int nele,s=0;
		public higharray1(int size)
		{
			a=new long[size];
			nele=0;
		}

	/*public int bsearch(long ele)
	{	
 		int flag=0;
		int u=nele;
		int l=0;
		int m;
		while(l<=u)
		{
			m=(l+u)/2;
			if(a[m]==ele)
			{
				flag=1;
				break;
			}
			else if(ele>a[m])
			l=m+1;
			else
			u=m-1;
		}
	return flag;
	}	
	public int delete(long value)
	{
		 int flag=0;
                int u=nele;
                int l=0;
		int m=0;
                while(l<=u)
                {
                        m=(l+u)/2;
                        if(a[m]==value)
                        {
                                flag=1;
                                break;
                        }
                        else if(value>a[m])
                        l=m+1;
                        else
                        u=m-1;
                }
        //return flag;

		//int j;
		
		//for(j=0;j<nele;j++)
		//if(value==a[j])
		//break;
		//if(j==nele)
		//return 0;
		//else  
		
			for(int k=m;k<nele-1;k++)
			a[k]=a[k+1];
			nele--;
			//return 1;
		
return flag;	
         }*/	


	public void insert(long value)
	{
		int k;
		int j=search(value);
                //int lb=0,ub=nele-1,mid,j,pos;
		//while(lb<=ub)
		//{	
			
			//mid=(lb+ub)/2;
			//if(a[mid]==value)
			//pos=mid;
			//else if(a[mid]<value)
			//lb=mid+1;
			//else
			//ub=mid-1;
		//}		
 		//int i,j;
		//for(i=0;i<nele;i++)
		//{
			//if(a[i]>value)
			//break;
		//}	
		for(k=nele;k>j;k--)
		a[k]=a[k-1];
		a[j]=value;
                 
//a[nele]=value;
		nele++;


       
	}
	public int search(long value)
        {
		int i;
		for(i=0;i<nele;i++)
		{
			if(a[i]>value)
			break;
		}
	return(i);
	}
	public void display()
	{
		for(int j=0;j<nele;j++)
		System.out.print(a[j]+" ");
		System.out.println("");
	}
	
	public void merge(higharray1 arr1,higharray1 arr2)
	{
		int i=0,j=0,k=0;
		while(i<arr1.nele && j<arr2.nele)
		{
			if(arr1.a[i]<arr2.a[j])
			{
				a[k]=arr1.a[i];
				k++;
				i++;
			}
			else if(arr1.a[i]>arr2.a[j])
			{
				a[k]=arr2.a[j];
				k++;
				j++;
			}
			else//if(arr1.a[i]==arr2.a[i])
			{
				a[k]=arr1.a[i];
				k++;
				i++;
				j++;
			}
		}
		while(j<arr2.nele)
		{
			a[k]=arr2.a[j];
			k++;
			j++;
		}
		while(i<arr1.nele)
		{
			a[k]=arr1.a[i];
			k++;
			i++;
		}
		nele=k;
	}
}

class orderarray
{
	public static void main(String args[])
	{
		higharray1 arr1=new higharray1(5);
		higharray1 arr2=new higharray1(4);
		higharray1 arr3=new higharray1(9);
		Scanner sc=new Scanner(System.in);
		for(int j=0;j<5;j++)
		{
			System.out.println("enter the array element of first array");
			long n=sc.nextLong();
			arr1.insert(n);
		}	
		for(int i=0;i<4;i++)
		{
			System.out.println("enter the elements of second array");
			long n=sc.nextLong();
			arr2.insert(n);
		}
		arr1.display();
		arr2.display();
		arr3.merge(arr1,arr2);
		arr3.display();
		//System.out.println("enter the number to be found");
		//long num=sc.nextLong();
		//int k=arr.bsearch(num);
		//if(k==1)
		//System.out.println("found");
		//else if(k==0)
		//System.out.println("not found");
//int searchkey=10;
//if(arr.find(searchkey))
//System.out.println("found");
//else 
//System.out.println("not found");
//long s=arr.getmax();
//System.out.println("the max of array is "+s);
//int s=arr.duplicate();
//for(int i=1;i<=s;i++)
//{
		//System.out.println("enter the element to be deleted");
		//long num1=sc.nextLong();
		//int t=arr.delete(num1);
//}
		//if(t==0)
		//System.out.println("number not present");
		//else 
		//System.out.println("array after deletion");
		//arr.display();
	}
}






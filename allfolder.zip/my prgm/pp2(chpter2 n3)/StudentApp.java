import java.util.Scanner;
 class Student
{
  private double mark;private String name;
	public Student(String nm,double m)
	{
	mark=m;
	name=nm;
	}	
	public void displays()
	{
	System.out.println(name);
	System.out.println(mark);
	public String getName()
	{
	return (name);
	}
	public double getMark()
	{
	return(mark);
}
}
 class StudentArray
{
	int nele;
	Student arr[];
	public StudentArray(int maxsize)
	{
	arr=new Student[maxsize];
	nele=0;
	}
	public void display()
	{
	for(int i=0;i<nele;i++)
	   arr[i].displays();
	}
	public void insert(String s,double m)
	{
	Student s1=new Student(s,m);
	arr[nele]=s1;
	nele++;
	}
	public void search(String nm)
 	{ int f=0;int p=0;
	for(int i=0;i<nele;i++)
		{
		if(nm.compareTo(arr[i].getName)==0)
		{
		f=1;p=i;
		break;}
	}
if(f==1)
System.out.println(nm+" "+arr[p].getMark);
else
System.out.println("not found");
}}
public class StudentApp
{
public static void main(String args[])
{
//Scanner sc=new Scanner(System.in);
//System.out.println("enter the name and mark");
//String nm=sc.next();
//int mark=sc.nextInt();

StudentArray s2=new StudentArray(5);
s2.insert("bhumica",90);
s2.insert("ritika",40);
s2.insert("koko",50);
s2.insert("sweta",85);
s2.insert("shreeja",95);
s2.display();
s2.search("koko");
}
}




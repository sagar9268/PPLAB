import java.util.*;
class node
{
	private int data1;
	private double data2;
	node next;
	
	public node(int x,double y)
	{
		data1=x;
		data2=y;
		next=null;
	}
	public void display()
	{
		System.out.println(data1+" "+data2);
	}
}
class llist
{
	node start,temp;
	void display()
	{
		temp=start;
		while(temp!=null)
		{
			temp.display();
			temp=temp.next;
		}
	}
	void create()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("press 1: to create a new node otherwise press 2");
		int a=sc.nextInt();
		while(a==1)
		{
			System.out.println("enter the value of x:");
			int x=sc.nextInt();
			System.out.println("enter the value of y:");
			double y=sc.nextDouble();
			node new1=new node(x,y);
			if(start==null)
			{
				start=new1;
				temp=new1;
			}
			else
			{
				temp.next=new1;
				temp=new1;
			}
			System.out.println("if you want to continue creating the new node then press 1:");
			 a=sc.nextInt();
		}
         }
	void insert_at_beg()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the value of x to insert at the beginning");
		int x=sc.nextInt();
		System.out.println("enter the value of y to insert at the biginning");
		double y=sc.nextDouble();
		node new2=new node(x,y);
		new2.next=start;
		start=new2;
	}	
	void delete_from_beg()
	{
		node t=null;
		if(start==null)
		System.out.println("linked list is empty");
		else
		{
			t=start;
		        start=start.next;
		}
		System.out.println("the deleted node is :");
		t.display();	
	}
	/*void search()
	{
		System.out.println("enter the value of x to search");
		int x=sc.nextInt();
		System.out.println("enter the value of y to search")
		double y=sc.nextDouble();
		node n4=new node(x,y);*/
		
}


public class linkedlist
{
	public static void main(String[] args)
	{
		llist l1=new llist();
		l1.create();
		l1.display();
		l1.insert_at_beg();
		System.out.println(" ");
		l1.display();
		l1.delete_from_beg();
		System.out.println(" ");
		l1.display();
	}
}

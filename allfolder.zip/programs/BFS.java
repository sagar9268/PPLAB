import java.util.*;
class BFS {

	int V;
	LinkedList<Integer> adj[];
	
	BFS(int v) {
		this.V = v;
		adj = new LinkedList[V];
		for(int i=0;i<V;i++) 
			adj[i] = new LinkedList<Integer>();
	}
	
	void addEdge(int v, int w) {
		adj[v].add(w);
	}
	
	void traverse(int src) {
	
		boolean visited[] = new boolean [V];
		LinkedList<Integer> queue = new LinkedList<Integer>();
		queue.add(src);
		while(queue.size()!=0) {
		
			src = queue.poll();
			System.out.print(src +" ");
			Iterator<Integer> i = adj[src].listIterator();
			while(i.hasNext()) {
				int n = i.next();
				if(!visited[n]) {
					visited[n]=true;
					queue.add(n);
				}
			}
		}
	}
	
	public static void main(String args[]) {
	
		BFS g = new BFS(4);
		g.addEdge(0, 1);
		g.addEdge(0, 2);
		g.addEdge(1, 2);
		g.addEdge(2, 0);
		g.addEdge(2, 3);
		g.addEdge(3, 3);
		g.traverse(2);
	}
}

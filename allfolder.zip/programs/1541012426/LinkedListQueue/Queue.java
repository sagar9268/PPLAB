class Queue {
	
	LinkedList list;
	Queue() {
		list = new LinkedList();
	}
	
	public void push(int key) {
		list.insertLast(key);
	}
	
	public int pop() {
		return list.delete();
	}
	
	public void display() {
		list.display();
	}
}

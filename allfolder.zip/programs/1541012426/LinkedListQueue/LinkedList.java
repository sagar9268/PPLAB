class LinkedList {
	
	Node first;
	Node last;
	LinkedList() {
		first = null;
		last = null;
	}

	public void insertFirst(int key) {
		
		Node newNode = new Node(key);
		if(first==null) {
			last = newNode;
		}
		newNode.next = first;
		first=newNode;
	}

	public void insertLast(int key) {
		
		Node newNode = new Node(key);
		if(first==null) {
			newNode.next = first;
			first = newNode;
			last = newNode;
		} else {
			last.next = newNode;
		}
	}

	public int delete() { 
		
		if(first != null ) {
			int temp = first.data;
			first = first.next;
			return temp;
		}
		return -1;
	}

	public void display() {

		Node current = first;
		while(current!=null) {
			current.displayNode();
			current = current.next;
		}
	}
	
	public void search(int key) {
	
		Node found = find(key);
		if(found == null) 
			System.out.println(key + " Not found");
		System.out.println(key + " Found");
	}
	
	public boolean deleteElement(int key) {
	
		Node current = first;
		Node previous = null;
		if(first.data == key) {
			first = first.next;
			return true;
		}
		while(current.data!=key) {
			if(current.next!=null) {
				previous = current;
				current = current.next;
			} else 
				return false;
		}
		previous.next = current.next;
		return true;
	}
	
	public Node find(int key) {
	
		Node current = first;
		while(current.data!=key) {
			if(current.next != null) {
				current = current.next;
			} else {
				return null;
			}
		}	
		return current;
	}
}

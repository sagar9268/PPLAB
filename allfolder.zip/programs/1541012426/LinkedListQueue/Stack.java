class Stack {

	LinkedList list;
	Stack() {
		list = new LinkedList();
	}
	
	public void push(int key) {
		list.insertFirst(key);
	}
	
	public Node pop() {
		return list.delete();
	}
}

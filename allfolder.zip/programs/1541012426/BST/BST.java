class BST {

	Node root;
	BST() {
		root = null;
	}
	
	public Node find(int key) {
		
		if(root == null) 
			return null;
		Node current = root;
		while(current.data!=key) {
		
			if(current.data>key) {
				current = current.left;
			} else {
				current = current.right;
			}
			if(current == null)
				return null;
		}
		return current;
	}
	
	public void preOrder() {
		preOrder_(root);
	}
	
	public void inOrder() {
		inOrder_(root);
	}
	
	public void postOrder() {
		postOrder_(root);
	}
	
	public void postOrder_(Node root) {
		
		if(root==null)
			return;
		postOrder_(root.left);
		postOrder_(root.right);
		root.display();
	}
	
	public void preOrder_(Node root) {
	
		if(root==null)
			return ;
		root.display();
		preOrder_(root.left);
		preOrder_(root.right);
	}
	
	public void inOrder_(Node root) {
	
		if(root==null)
			return;
		inOrder_(root.left);
		root.display();
		inOrder_(root.right);
	}
	
	public boolean insertNode(int key) {
		
		root = insert(root, key);
		return root==null ? false : true;
	}
	
	public Node insert(Node root, int key) {
	
		if(root == null)
			return new Node(key);
			
		if(key<=root.data) 
			root.left = insert(root.left, key);
		else 
			root.right = insert(root.right, key);
		return root;
	}
}

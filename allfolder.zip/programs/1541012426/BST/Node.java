class Node {
	
	int data;
	Node left;
	Node right;
	Node(int key) {
	
		this.data = key;
		this.left = null;
		this.right = null;
	}
	
	void display() {
		System.out.println(data);
	}
}

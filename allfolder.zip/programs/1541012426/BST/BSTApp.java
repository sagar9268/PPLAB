import java.util.*;
class BSTApp {

	public static void main(String args[]) {
	
		Scanner sc = new Scanner(System.in);
		int ch=1;
		BST obj = new BST();
		int key=0;
		while(ch!=0) {
		
			System.out.println("0.Exit\n1.Insert\n2.Find\n3.InOrder\n4.PostOrder\n5.PreOrder");
			ch = sc.nextInt();
			switch(ch) {
			
				case 0:
					return;
					
				case 1:
					System.out.println("Enter element");
					key = sc.nextInt();
					boolean result = obj.insertNode(key);
					if(result)
						System.out.println("Insertion successfull");
					else
						System.out.println("Unable to insert");
					break;
				case 2:
					System.out.println("Enter element to search");
					key = sc.nextInt();
					Node ele = obj.find(key);
					if(ele==null)
						System.out.println("Element no found");
					else 
						ele.display();
					break;
				case 3:
					obj.inOrder();
					break;
				case 4: obj.postOrder();
					break;
				case 5: obj.preOrder();
					break;
				default:
					System.out.println("Invalid");
			}
		}
	}
}

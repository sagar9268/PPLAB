import java.util.Scanner;
class Rotate {
	
	String str;
	String getString() {
		return str;
	}
	Rotate(String str) {
		this.str = str;
	}
	public void rotate(int n) {
		
		char s[] = str.toCharArray();
		int len = s.length;
		char ch = s[n];
		for(int i=n+1 ; i<len;i++) {
			s[i-1]=s[i];
		}
		s[len-1] = ch;
		for(int i=0;i<len;i++)
			System.out.print(" " +s[i]);
	}
	
	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string");
		String str = sc.next();
		Rotate obj = new Rotate(str);
		System.out.println("Enter index");
		int n = sc.nextInt();
		obj.rotate(n);
	}
}

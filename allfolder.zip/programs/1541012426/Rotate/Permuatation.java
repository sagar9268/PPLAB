class Permutation {

}

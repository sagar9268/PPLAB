class Vertex {

	char name;
	boolean wasVisited;
	
	Vertex(char name) {
		this.name = name;
		wasVisited = false;
	}
}

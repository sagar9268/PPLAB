class Stack {

	int MAX;
	int stack[];
	int top;
	Stack(int max) {
		stack = new int[max];
		MAX = max;
		top = -1;
	}
	
	boolean isEmpty() {
		return top==-1;
	}
	
	boolean isFull() {
		return top==MAX;
	}
	
	void push(int ele) {
		stack[++top] = ele;
	}
	
	int peek() {
		return stack[top];
	}
	
	int pop() {
		return stack[top--];
	}
}

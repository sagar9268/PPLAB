class Graph {

	Vertex vertex[];
	static int MAX = 20;
	int adjMat[][];
	int noVertex;
	Stack stack;
	
	Graph() {
	
		vertex = new Vertex[MAX];
		adjMat = new int[MAX][MAX];
		noVertex = 0;
		stack = new Stack(MAX);
	}
	
	void addEdge(int start, int end) {
		adjMat[start][end] = 1;
		adjMat[end][start] = 1;
	}
	
	void addVertex(char lab) {
		vertex[noVertex++] = new Vertex(lab);
	}
	
	void display(int v) {
		System.out.print(vertex[v].name);
	}
	
	void dfs() {
	
		vertex[0].wasVisited = true;
		display(0);
		stack.push(0);
		while (!stack.isEmpty() ) {
		
			int v = getUnvisitedVertex(stack.peek());
			if(v==-1) 
				stack.pop();
			else {
			
				vertex[v].wasVisited = true;
				display(v);
				stack.push(v);
			}
		}
	}
	
	int getUnvisitedVertex(int v) {
	
		for(int i =0 ; i < noVertex ; i++ ) {
			if( adjMat[v][i]==1 && !vertex[i].wasVisited)
				return i;
		}
		return -1;
	}
	
	public static void main(String args[]) {
	
		Graph g = new Graph();
		g.addVertex('A');
		g.addVertex('B');
		g.addVertex('C');
		g.addVertex('D');g.addVertex('F');
		g.addVertex('E');
		g.addEdge(0,1);
		g.addEdge(1,2);
		g.addEdge(0,3);
		g.addEdge(3,4);
		System.out.println("Visits ");
		g.dfs();
	}
}

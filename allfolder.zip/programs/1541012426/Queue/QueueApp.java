import java.util.Scanner;
class QueueApp {

	public static void main(String args[]) {

		int maxSize;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		maxSize = sc.nextInt();
		Queue obj = new Queue(maxSize);
		int ch = 1;
		int ele;
		while(ch!=0) {
			System.out.println("0.Exit\n1.Push\n2.Pop\n3.Display");
			ch=sc.nextInt();
			switch(ch) {
				case 0: return;

				case 1: System.out.println("Enter a element");
					ele = sc.nextInt();
					obj.push(ele);				
					break;

				case 2: ele = obj.pop();
					System.out.println(ele);	
					break;
		
				case 3: obj.display();
					break;
				default: System.out.println("Invalid");
			}
		}
	}	
}

class Queue {
	
	private int maxSize;
	private int arr[];
	private int front;
	private int rear;

	Queue(int maxSize) {
		this.maxSize = maxSize + 1;
		arr = new int[this.maxSize];
		front = 0;
		rear = -1;
	}

	public boolean isEmpty() {
		return ( (front == rear + 1) || (front + maxSize - 1 == rear) );
	}

	public boolean isFull() {
		return ( (front == rear + 2) || (front + maxSize -2 == rear) ); 
	}

	public void push(int key) {
		
		if(!isFull()) {
			if(rear == maxSize) 
				rear = -1;
			arr[++rear] = key;
		} else {
			System.out.println("Queue is full");
		}
	}

	public int pop() {

		if(!isEmpty()) {
			int temp = arr[front++];
			if(front==maxSize) 
				front = -1;
			return temp;
		} else {
			System.out.println("Queue is empty");
			return -1;
		}
	}

	public void display() {
		if(front < rear) {
			for(int i=front;i<=rear;i++){
				System.out.println(arr[i]);
			}
		} else {
			for(int i=front;i<maxSize;i++)
				System.out.println(arr[i]);
			for(int i=0;i<=rear;i++) 
				System.out.println(arr[i]);
		}
	}
}

class BinaryTree {

	Node root;
	BinaryTree() {
		root = null;
	}
	
	boolean insert(int key) {
	
		if(root == null) {
			root = new Node(key);
			return true;
		}
		
		Queue<Node> q = LindkedList<Node>();
		q.add(root);
		while(q.size() > 0) {
			
			Node temp = q.peek();
			q.remove();
			if(temp.left!=null) {
				q.add(temp.left);
			} else if(temp.left==null {
				temp.left = new Node(key);
				return true;
			} else if(temp.right != null) {
				q.add(temp.right);
			} else {
				temp.right = new Node(key);
				return true;
			}
		}
		return false;
	}
}

class Node {

	Node left;
	Node right;
	int data;
	Node(int data) {
		this.data = data;
		this.left = null;
		this.right = null;
	}
	
	void displayNode() {
		System.out.println(data);
	}
}

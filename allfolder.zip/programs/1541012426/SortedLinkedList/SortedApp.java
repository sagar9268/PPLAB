import java.util.Scanner;
class SortedApp {
	
	public static void main(String args[]) {

		LinkedList list = new LinkedList();
		Scanner sc =new Scanner(System.in);
		int ch=1;
		int key;
		while(ch!=0) {
			System.out.println("**********************************************************");
			System.out.println("0.Exit\n1.Insert\n2.Delete\n3.Display\n4.Search\n5.Delete Element");
			ch=sc.nextInt();
			switch(ch) {
				case 1: System.out.println("Enter a number");
					key = sc.nextInt();
					list.insert(key);
					break;
				
				case 2: System.out.println("Deleting number");
					key = list.delete();
					System.out.println("Number deleted = "+key);
					break;
					
				case 3: System.out.println("List contains");
					list.display();
					break;
					
				case 4: System.out.println("Enter element to search");
					key = sc.nextInt();
					list.search(key);
					break;
					
				case 5: System.out.println("Enter element to delete");
					key = sc.nextInt();
					boolean found = list.deleteElement(key);
					if(found) 
						System.out.println("Element deleted");
					else
						System.out.println("Element not found");
					break;
					
				default:System.out.println("Invalid input");
			}
		}
	}
}

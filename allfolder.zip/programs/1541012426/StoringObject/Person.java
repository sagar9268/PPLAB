import java.util.Scanner;

public class Person {
	
	String firstName;
	String lastName;
	int age;

	public Person(String firstName, String lastName, int age) {
		this.firstName=firstName;
		this.lastName=lastName;
		this.age=age;
	}

	public String getLastName() {
		return this.lastName;
	}
	
	public String getFirstName() {
		return this.firstName;
	}

	public int getInt() {
		return this.age;
	}

	public void display() {
		System.out.println("Fisrt Name="+firstName+"\nLast Name="+lastName+"\nAge="+age);
	}
}

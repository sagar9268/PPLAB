import java.util.Scanner;

public class App {
	public static void main(String args[]) {
	
		Scanner sc = new Scanner(System.in);
		int size;
		System.out.println("Enter the array size:");
		size=sc.nextInt();
		PersonArray personArray = new PersonArray(size);
		int age;
		String firstName;
		String lastName;
		int choice=1;
		while(choice!=0) {
		
			System.out.println("0.Exit\n1.Insert\n2.Display\n3.Delete");
			choice=sc.nextInt();
			switch(choice) {
			
				case 1: 	
					System.out.println("Enter the age");
					age = sc.nextInt();
					System.out.println("Enter first name");
					firstName = sc.next();
					System.out.println("Enter last name");
					lastName = sc.next();
					personArray.insert(firstName, lastName, age);
					break;
			
				case 2:
					personArray.display();
					break;

				case 3: System.out.println("Enter last name");
					lastName=sc.next();
					personArray.delete(lastName);
					break;
			
				case 4:
					personArray.insertionSort();
					break;
				
				default:return;
			}
		}
	}
}

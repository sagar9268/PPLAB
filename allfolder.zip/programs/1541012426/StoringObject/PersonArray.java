import java.util.Scanner;

public class PersonArray {
	
	Person persons[];
	int nElements;
	int maxSize;

	public PersonArray(int size) {
		persons = new Person[size];
		this.maxSize=size;
		this.nElements=0;
	}

	public void insert(String firstName, String lastName, int age) {
		persons[nElements++] = new Person(firstName, lastName, age);
	}

	public void display() {
		
		for(int i=0;i<nElements;i++) {
			persons[i].display();
		}
	}

	public void delete(String lastName) {
		
		for(int i=0;i<nElements;i++) {
			
			if(lastName.equals(persons[i].getLastName())) {
				deleteRecord(i);
				break;
			}
		}
	}

	private void deleteRecord(int index) {
		
		for(int i=index;i<nElements-1;i++) {
			persons[i]=persons[i+1];
		}
		nElements--;
	}

	public void insertionSort() {
		
		for(int i=0;i<nElements;i++) {

			
		}
	}
}	

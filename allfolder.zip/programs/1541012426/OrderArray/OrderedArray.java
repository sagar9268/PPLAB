class OrderedArray {
	
	private int size;
	private int arr[];
	private int arrSize;
	
	public OrderedArray(int size) {
		this.size = size;
		this.arr = new int[this.size];
		this.arrSize=0;
	}

	public void display() {
		
		for(int i = 0; i < this.arrSize; i++) {
			System.out.println(this.arr[i]);
		}
	}

	public String insert(int ele) {
		
		int index = this.find(ele);
		
		return shift(index,ele);
	}

	public int find(int value) {

		return binarySearch(value);
	}

	public void delete(int value) {
	
		if(this.arrSize != 0) {
			int index = this.find(value);
			for(int i=index;i<this.arrSize-1;i++) {
				this.arr[i] = this.arr[i+1];
			}
			this.arrSize--;
		}
	}

	private String shift(int index, int ele) {

		if(this.arrSize > this.size) {
			return "Failed to insert";
		}

		if(this.arrSize==0) {
			this.arr[0]=ele;
			this.arrSize++;
			return "Success";
		}
		int i;
		for(i= this.arrSize;i>index;i--) {
			this.arr[i] = this.arr[i-1];
		}

		this.arr[i]= ele;
		this.arrSize++;
			return "Success";
	}		
	
	private int getIndex(int ele) {
	
		if(this.arrSize==0)
			return 0;
		for(int i=0;i<this.arrSize;i++) {
			if(this.arr[i] > ele) {
				return i;
			}
		}
		return 0;
	}

	public int binarySearch(int ele) {
		return binary_Search(0,this.arrSize, ele);
	}

	private int binary_Search(int low, int high, int ele) {
		
		if(this.arrSize == 0)
			return 0;

		if(ele <= arr[low])
			return low;

		if(ele > arr[high])
			return this.arrSize;

		int mid=(low+high)/2;

		if(this.arr[mid]==ele)
			return mid;

		if(this.arr[mid]<ele) {

			if(mid+1<=high && arr[mid+1]>ele)
				return mid+1;
			return binary_Search(mid+1,high,ele);
		} else {

			if(mid-1 >=low && arr[mid-1]<ele)
				return mid;
			return binary_Search(low, mid-1, ele);
		}
	}

	public void merge(OrderedArray obj1, OrderedArray obj2) {
		
		int i=0, k=0, j=0;
		while(obj1.arrSize>i && obj2.arrSize>j) {
			
			if(obj1.getValue(i) > obj.getValue(j) {

				this.arr[k] = obj1.getValue(j);
				j++;
			} else {
				
				this.arr[k] = obj2.getValue(i);
				i++;
			}
			k++;
		}
		this.arrSize = k;
	}


}

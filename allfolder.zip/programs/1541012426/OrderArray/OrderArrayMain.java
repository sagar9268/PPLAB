import java.util.Scanner;

class OrderArrayMain {
	public static void main(String args[]) {
		
		int size;
		Scanner sc=new Scanner(System.in);
		System.out.println("\nEnter the size of array");
		size=sc.nextInt();
		OrderedArray orderArr = new OrderedArray(size);
		OrderedArray orderArr1 = new OrderedArray(size);
		OrderedArray mergeArr = new OrderedArray(size);
		int ch=1;
		while(ch!=0) {
			System.out.println("Enter your choice");
			System.out.println("0.Exit\n1. insert\n2.Display\n3.Search\n4Delete\n5.Insert new array\n6.merge");
			ch=sc.nextInt();
			switch(ch) {
				case 1: System.out.println("Enter a number");
					int num;
					num=sc.nextInt(); 
					System.out.println(orderArr.insert(num));
					break;

				case 2: orderArr.display();
					break;

				case 3: System.out.println("Enter element to search");
					int ele;
					ele=sc.nextInt();
					int index = orderArr.binarySearch(ele);
					System.out.println("Index="+index);
					break;
				case 4: System.out.println("Enter ele to delete");
					ele=sc.nextInt(); 
					orderArr.delete(ele);
					break;
				case 5: 
					System.out.println("Enter a number");
					num=sc.nextInt(); 
					System.out.println(orderArr1.insert(num));
					break;
				case 6: mergeArr.order(orderArr, orderArr1);
					mergeArr.display();
					break;
				default:
					System.out.println("Invalid");
			}
		}
	}
}

import java.util.*;
class Triangular {

	public static int triangular(int n) {
	
		if(n==1)
			return 1;
		return triangular(n-1) + n;
	}
	
	public static void main(String args[]) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int n = sc.nextInt();
		System.out.println("Triamgular number =" + triangular(n));
	}
}

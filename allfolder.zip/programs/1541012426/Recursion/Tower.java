import java.util.*;
class Tower {

	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		Tower obj = new Tower();
		int n;
		System.out.println("Enter number of disc");
		n = sc.nextInt();
		obj.tower(n, 'A', 'B', 'C');
	}
	
	public void tower(int n , char from, char inter, char to) {
	
		if(n==1)
			System.out.println("Disc " + n + " from " + from + " to " + to);
		else {
			tower(n-1, from , to, inter);
			System.out.println("Disc " + n + " from " + from + " to " + to);
			tower(n-1, inter, from, to);
		}
	}
}

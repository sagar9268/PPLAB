import java.util.Scanner;
class Power {

	int power(int x, int y) {
	
		if(x == 0)
			return 0;
		if(y == 0)
			return 1;
		return power(x, y-1) * x;
	}
	
	public static void main(String args[] ) {
	
		Scanner sc = new Scanner(System.in);
		Power obj = new Power();
		System.out.println("Enter x");
		int x = sc.nextInt();
		System.out.println("Enter y");
		int y = sc.nextInt();
		System.out.println("Power (" + x +","+ y+")=" + obj.power(x,y));
	}
}

import java.util.Scanner;
class Multi {

	int multi(int x, int y) {
	
		if(x == 0 || y==0)
			return 0;
		return multi(x, y-1) + x;
	}
	
	public static void main(String args[] ) {
	
		Scanner sc = new Scanner(System.in);
		Multi obj = new Multi();
		System.out.println("Enter x");
		int x = sc.nextInt();
		System.out.println("Enter y");
		int y = sc.nextInt();
		System.out.println("Product=" + obj.multi(x,y));
	}
}

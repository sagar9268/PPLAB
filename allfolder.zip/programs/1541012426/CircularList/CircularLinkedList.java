class CircularLinkedList {
	
	Node current;
	CircularLinkedList() {
		current = null;
	}

	public void insert(int key) {
		
		Node newNode = new Node(key);
		if(current == null) {
			current = newNode;
			newNode.next = current;
		} else {
			newNode.next = current.next;
			current.next = newNode;
			current=newNode;
		}
	}

	
	public void display() {
		
		Node temp = current;
		do {
			temp.displayNode();
			temp = temp.next;
		} while(temp!= current);
	}
	
	public void search(int key) {
		Node stopper = current;
		Node currentPtr = current;
		do {
			if(currentPtr.data == key) {
				currentPtr.displayNode();
				return ;
			}
			currentPtr = currentPtr.next;
		} while(currentPtr!=stopper);
		System.out.println("Not found");
	}
	
	public Node delete(int key) {
	
		Node previousPtr = current;
		if(current == null ) 
			return null;
		Node currentPtr = current.next;
		Node stopper = current;
		if(previousPtr.next == stopper) {
			current = null;
			return current;
		}
		do {
			if(currentPtr.data == key) {
				previousPtr.next = currentPtr.next;
				current = previousPtr;
				return currentPtr;
			}
			currentPtr = currentPtr.next;
			previousPtr = previousPtr.next;
		} while(previousPtr != stopper);
		
		return current;
	}
}

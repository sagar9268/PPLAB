import java.util.Scanner;
class CircularListApp {
	
	public static void main(String args[]) {

		CircularLinkedList list = new CircularLinkedList();
		Scanner sc =new Scanner(System.in);
		int ch=1;
		int key;
		while(ch!=0) {
			System.out.println("**********************************************************");
			System.out.println("0.Exit\n1.Insert\n2.Delete\n3.Display\n4.Search");
			ch=sc.nextInt();
			switch(ch) {
				case 1: System.out.println("Enter a number");
					key = sc.nextInt();
					list.insert(key);
					break;
				
				case 2: System.out.println("Enter a number to delete");
					key = sc.nextInt();
					System.out.println("Deleting number");
					Node result = list.delete(key);
					System.out.println("Number deleted");
					break;
					
				case 3: System.out.println("List contains");
					list.display();
					break;
					
				case 4: System.out.println("Enter element to search");
					key = sc.nextInt();
					list.search(key);
					break;
					
				default:System.out.println("Invalid input");
			}
		}
	}
}

import java.util.Scanner;

class Stack {
	
	private char arr[];
	private int maxSize;
	private int top;
	
	Stack(int maxSize) {
		this.maxSize=maxSize;
		arr=new char[maxSize];
		top=-1;
	} 
	
	public boolean isFull() {
		return (maxSize == top+1) ? true : false;
	}
	
	public boolean isEmpty() {
		return (top==-1) ? true : false;
	}
	
	private int getPeekIndex() {
		return this.top;
	}
	
	public char peek() {
		return arr[top];
	}
	
	public void push(char ele) {
	
		if(!isFull()) {
			arr[++top]=ele;
		}
	}
	
	public char pop() {
		System.out.println(top);
		if(!isEmpty()) {
			char ele = arr[top];
			top--;
			return ele;
		}
		return '0';
	}
	
	public void display() {
		
		for(int i=getPeekIndex(); i>=0; i--) {
			System.out.println(arr[i]);
		}
	}
}

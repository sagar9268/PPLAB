import java.util.Scanner;

class BracketChecking {

	private String str;
	private int len;
	BracketChecking(String str) {
		this.str=str;
		this.len=str.length();
	}
	Stack stack = new Stack(len);
	int temp=0;
	
	public void checkBrackets() {
	
		for(int i=0; i < str.length(); i++) {
			
			char s=str.charAt(i);
			
			switch(s) {
			
				case '{' :
				case '[' :
				case '(' : stack.push(s);
					   break;
				case '}' :
				case ']' :
				case ')' : if(!stack.isEmpty()) {
						char sx = stack.pop();
						System.out.println(sx);
						if( (s==')' && sx!='(') || 
						    (s==']' && sx!='[') ||
						    (s=='}' && sx!='{') ) {
						  	System.out.println("Errorr:"+s+" at " +i);
						 } 
					   }	 
					   else {
					 	System.out.println("Errorr:"+s+" at " +i);
					 }
					break;
				default : break;	  	
			}
		}
		if(!stack.isEmpty())
			System.out.println("Error missing right delimiter");
	}
}

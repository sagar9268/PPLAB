import java.util.Scanner;

class DelimiterApp {

	public static void main(String args[]) {
	
		String str="";
		Scanner sc= new Scanner(System.in);
		int choice =1;
		while(choice!=0) {
		
			System.out.println("0.Exit\n1.Enter String\n2.Check brackets");
			choice = sc.nextInt();
			switch(choice) {
			
				case 0: return;
				
				case 1: 
					System.out.println("Enter a string");
					str=sc.next();
					break;
				
				case 2:
					System.out.println("Current stirng="+str);
					BracketChecking brCheck= new BracketChecking(str);
					brCheck.checkBrackets();
					break;
					
				default:
					System.out.println("Invalid");
			}
		}
	}
	 
}

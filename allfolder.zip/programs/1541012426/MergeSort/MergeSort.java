import java.util.*;
class MergeSort {

	int arr[];
	int length;
	MergeSort(int arr[]) {
		this.arr = arr;
		length = arr.length;
	}
	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n =  sc.nextInt();
		int arr[] = new int[n];
		for(int i = 0;i<n;i++)
			arr[i]= sc.nextInt();
		MergeSort obj = new MergeSort(arr);
		int tempArr[] = new int[n];
		obj.mergeSort(tempArr,0, n);
		obj.display();
	}
	
	public void display() {
		for(int i = 0 ; i < length ; i++)
			System.out.print(arr[i] + " " );
	}
	
	public void mergeSort(int tempArr[], int low, int high) {
		
		if(low==high)
			return;
		int mid = (low+high)/2;
		mergeSort(tempArr,low, mid);
		mergeSort(tempArr,mid+1, high);
		merge(tempArr,low,mid, high);
	}
	
	public void merge(int tempArr[], int low, int mid, int high) {
	
		int i = low;
		int j = mid;
		int k = 0;
		while(i < mid && j<high) {
			
			if(arr[i] < arr[mid] ) {
				tempArr[k++] = arr[i++];
			} else {
				tempArr[k++]= arr[j++];
			}
		}
		
		while(i<mid) {
			tempArr[k++] = arr[i++];
		}
		
		while(j<high) {
			tempArr[k++] = arr[j++];
		}
		
		int n = high - low;
		for(i = 0 ; i < n ; i++) {
			arr[low+i] = tempArr[i]; 
		}
	}
}

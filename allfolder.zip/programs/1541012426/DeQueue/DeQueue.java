class DeQueue {

	private int arr[];
	private int maxSize;
	private int nItems;
	private int left;
	private int right;

	DeQueue(int maxSize) {
		arr = new int[maxSize];
		nItems = 0;
		left = 0;
		right = -1;
		this.maxSize= maxSize;
	}

	public boolean isFull() {
		return nItems == maxSize - 1;
	}

	public boolean isEmpty() {
		return nItems == 0;
	}

	public void insertLeft(int key) {

		if(!isFull()) {
			left--;
			if(left<0) 
				left = maxSize-1;
			arr[left]=key;
			nItems++;
		}
	}

	public void insertRight(int key) {

		if(!isFull()) {
			right++;
			if(right>=maxSize) 
				right = 0;
			arr[right]=key;
			nItems++;
		}
	}

	public int removeRight() {
	
		if(!isEmpty()) {
			nItems--;
			return arr[right--];
		}
		return -1;
	}

	public int removeLeft() {
		
		if(!isEmpty()) {
			nItems--;
			return arr[left++];
		}
		return -1;	
	}
}

import java.util.Scanner;
class App {
	
	public static void main(String args[]) {

		int len, num, remove;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of array");
		len = sc.nextInt();
		DeQueue obj = new DeQueue(len);
		int ch = 1;

		while (ch != 0) {

			System.out.println("0.Exit\n1.Insert Left\n2.Insert Right\n3.Remove Right\n4.Remove Left");
			ch = sc.nextInt();
			switch(ch) {

				case 0: return;

				case 1: System.out.println("Enter number");
					num =sc.nextInt();
					obj.insertLeft(num);
					break;

				case 2: System.out.println("Enter number");
					num = sc.nextInt();
					obj.insertRight(num);
					break;
		
				case 3: System.out.println("Removing from right");
					remove = obj.removeRight();
					if(remove==-1)
						System.out.println("Empty list");
					else 
						System.out.println("Removed "+remove);
					break;
		
				case 4: System.out.println("Removing from left");
					remove = obj.removeLeft();
					if(remove==-1)
						System.out.println("Empty list");
					else 
						System.out.println("Removed "+remove);
					break;

				default:System.out.println("Invalid");
			}
		}
	}
}

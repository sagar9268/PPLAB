class Stack {

	int maxSize;
	char arr[];
	int top;
	
	Stack(int size) {

		this.maxSize = size;
		arr = new char[size];
		top=-1;
	}
	
	public void push(char key) {
		arr[++top] = key;
	}

	public char pop() {
		return arr[top--];
	}

	public char getPeekN(int index) {
		return arr[index];
	}

	public char getPeek() {
		return arr[top];
	}

	public boolean isFull() {
		return (top==maxSize) ? true : false;
	}

	public boolean isEmpty() {
		return (top==-1) ? true : false;
	}

	public void display(String s) {
		
		System.out.println(s);
		System.out.print("Stack (bottom-->top):");
		for(int j=0; j<size(); j++) {
			System.out.println(peekN(j));
			System.out.print(' ');
		}
		System.out.println();
	}
}

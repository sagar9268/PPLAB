class InToPost {
	
	private String output="";
	private String input;
	private Stack stack;

	InToPost(String str) {
		input = str;
		stack = new Stack(str.length());
	}

	public String doTrans() {
	
	}
}

import java.util.Scanner;
class StackApp {
	
	public static void main(String args[]) {
		
		Stack stack = new Stack();
		Scanner sc =new Scanner(System.in);
		int ch=1;
		int key;
		while(ch!=0) {
			System.out.println("**********************************************************");
			System.out.println("0.Exit\n1.Insert\n2.Delete\n3.Display");
			ch=sc.nextInt();
			switch(ch) {
			
				case 0:
					return ;
					
				case 1: System.out.println("Enter a number");
					key = sc.nextInt();
					stack.push(key);
					break;
				
				case 2: System.out.println("Deleting number");
					key = stack.pop();
					System.out.println("Number deleted = "+key);
					break;
					
				case 3: System.out.println("List contains");
					stack.display();
					break;
					
				default:System.out.println("Invalid input");
			}
		}
	}
}

class DoubleLinkedList {
	
	Node first;
	DoubleLinkedList() {
		first = null;
	}

	public void insert(int key) {
		
		Node newNode = new Node(key);
		if(first!=null) {
			first.prev = newNode;
		}
		newNode.next = first;
		first=newNode;
	}

	public int delete() { 
		
		if(first != null ) {
		
			int temp = first.data;
			first = first.next;
			first.prev = null;
			return temp;
		}
		return -1;
	}

	public void display() {

		Node current = first;
		while(current!=null) {
			current.displayNode();
			current = current.next;
		}
	}
	
	public void search(int key) {
	
		Node found = find(key);
		if(found == null) 
			System.out.println(key + " Not found");
		System.out.println(key + " Found");
	}
	
	public boolean deleteElement(int key) {
	
		Node current = first;
		if(first.data == key) {
			first = first.next;
			if(first!=null)
				first.prev = null;
			return true;
		}
		
		while(current.data!=key) {
			if(current.next!=null) {
				current = current.next;
			} else 
				return false;
		}
		
		if(current.next==null) {
			current.prev.next = null;
		} else {
			current.next.prev = current.prev;
			current.prev.next = current.next;
		}
		
		return true;
	}
	
	public Node find(int key) {
	
		Node current = first;
		while(current.data!=key) {
		
			if(current.next != null) {
				current = current.next;
			} else {
				return null;
			}
		}	
		
		return current;
	}
}

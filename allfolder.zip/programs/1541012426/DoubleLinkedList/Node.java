class Node {
	
	public int data;
	public Node next;
	public Node prev;

	Node() {

	}
	Node(int data) {
		this.data = data;
		this.next = null;
		this.prev = null;
	}

	public void displayNode() {
		System.out.println("Data=" + data);
	}
}

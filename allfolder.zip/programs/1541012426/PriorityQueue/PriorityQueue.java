class PriorityQueue {

	int arr[];
	int maxSize;
	int nItems;
	
	PriorityQueue(int maxSize) {
		this.maxSize = maxSize;
		arr = new int[maxSize];
		nItems=0;
	}

	public void insert(int key) {

		if(isEmpty()) {
			arr[nItems++]=key;
		} else {
			int j;
			for(j=nItems-1;j>=0;j--) {
				if(key>arr[j]) {
					arr[j+1] = arr[j];
				} else {
					break;
				}
			}
			arr[j+1]=key;
			nItems++;
		}
	}

	public int getPeek() {
		return arr[nItems-1];
	}

	public int remove() {
		if(!isEmpty())
			return arr[--nItems];
		return -1;
	}
	
	public boolean isFull() {
		return (nItems==maxSize) ? true : false;
	}
	
	public boolean isEmpty() {
		return (nItems==0) ? true : false;
	}
}

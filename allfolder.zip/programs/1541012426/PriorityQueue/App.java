import java.util.Scanner;
class App {
	
	public static void main(String args[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int size = sc.nextInt();
		PriorityQueue obj = new PriorityQueue(size);
		int ch=1, ele;
		while(ch!=0) {
			
			System.out.println("Enter your choice");
			System.out.println("0.Exit\n1.Insert\n2.Remove\n3.GetPeek");
			ch=sc.nextInt();
			switch(ch) {
			
				case 0: return ;
				case 1: System.out.println("Insert a element");
					ele = sc.nextInt();
					obj.insert(ele);
					break;
				case 2: ele=obj.remove();
					System.out.println("Element removed="+ele);
					break;
				case 3: System.out.println("Peek value="+ obj.getPeek());
					break;
				default:System.out.println("Invalid");
			}
		}
	}
}

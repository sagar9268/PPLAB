class Graph {

	Vertex vertex[];
	int adjMat[][];
	int noVertex;
	static int MAX = 20;
	private char sortedArray[];
	Graph() {
	
		vertex = new Vertex[MAX];
		adjMat = new int[MAX][MAX];
		noVertex = 0;
		sortedArray = new char[MAX];
	}
	
	void addEdge(int start, int end) {
		adjMat[start][end] = 1;
	}
	
	void addVertex(char lab) {
		vertex[noVertex++] = new Vertex(lab);
	}
	
	void display(int v) {
		System.out.print(vertex[v].name);
	}
	
	public void topo() {
	
		int orig_noVertex = noVertex;
		while(noVertex > 0) {
		
			int currentVertex = noSuccessors();
			if(currentVertex == -1) {
				System.out.println("Error: Graph has cycle");
				return;
			}
			sortedArray[noVertex-1] = vertex[currentVertex].name;
			deleteVertex(currentVertex);
		}
		System.out.println("Topological sorted order: ");
		for(int j=0;j<orig_noVertex;j++) 
			System.out.print(sortedArray[j]);
		System.out.println();
	}
	
	public int noSuccessors() {
	
		boolean isEdge;
		for(int row = 0; row<noVertex; row++) {
		
			isEdge = false;
			for(int col = 0; col < noVertex;col++) {
				if(adjMat[row][col] > 0) {
					isEdge = true;
					break;
				}
			}
			if(!isEdge) 
				return row;
		}
		return -1;
	}
	
	public void deleteVertex(int ver) {
	
		if(ver != noVertex - 1) {
		
			for(int j = ver;j<noVertex-1;j++) {
				vertex[j] = vertex[j+1];
			}
			
			for(int row = ver;row<noVertex-1;row++) {
				moveRowUp(row, noVertex);
			}
			
			for(int col = ver;col<noVertex-1;col++) {
				moveColLeft(col, noVertex-1);
			}
			noVertex--;
		}
	}
	
	private void moveRowUp(int row, int length) {
	
		for(int col = 0; col<length;col++) {
			adjMat[row][col] = adjMat[row+1][col];
		}
	}
	
	private void moveColLeft(int col, int length) {
	
		for(int row= 0;row<length;row++) {
			adjMat[row][col] = adjMat[row][col+1];
		}
	}
	
	public static void main(String args[]) {
	
		Graph g = new Graph();
		g.addVertex('A');
		g.addVertex('B');
		g.addVertex('C');
		g.addVertex('D');
		g.addVertex('F');
		g.addVertex('E');
		g.addEdge(0,1);
		g.addEdge(1,2);
		g.addEdge(0,3);
		g.addEdge(3,4);
		System.out.println("Visits ");
		g.topo();
	}
}

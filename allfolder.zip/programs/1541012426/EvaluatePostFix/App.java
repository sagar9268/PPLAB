import java.util.Scanner;

class App {

	public static void main(String args[]) {
	
		String str="";
		Scanner sc= new Scanner(System.in);
		
		int choice =1;
		while(choice!=0) {
		
			System.out.println("0.Exit\n1.Enter String");
			choice = sc.nextInt();
			switch(choice) {
			
				case 0: return;
				
				case 1: 
					System.out.println("Enter a string");
					str=sc.next();
					EvaluatePostFix obj = new EvaluatePostFix(str);
					int answer = obj.evaluatePost();
					System.out.println("Result = " +answer);
					break;

				default:
					System.out.println("Invalid");
			}
		}
	}
	 
}

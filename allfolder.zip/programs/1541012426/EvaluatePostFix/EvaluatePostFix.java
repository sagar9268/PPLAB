class EvaluatePostFix {

	private String str;
	private int length;
	
	EvaluatePostFix(String str) {
		this.str = str;
		length = this.str.length();
	}

	public int evaluatePost() {
	
		int num1, num2, interResult = 0;
		char ch;
		Stack stack = new Stack(20);
		for(int i=0 ;i < length; i++) {

			ch = str.charAt(i);
			if(ch >='0' && ch <='9') {
				stack.push((int) ch-'0');
			} else {
				num2 = stack.pop();
				num1 = stack.pop();
				switch(ch) {
			
					case '+': interResult = num1 + num2;
						break;
					
					case '-': interResult = num1 - num2;
						break;
		
					case '/': interResult = num1 / num2;
						break;
	
					case '*': interResult = num1 * num2;
						break;
			
					default :
						interResult = 0;
				}
				stack.push(interResult);
			}
		}
		interResult = stack.pop();
		return interResult;
	}
}

class Stack {

	int maxSize;
	int arr[];
	int top;
	
	Stack(int size) {

		this.maxSize = size;
		arr = new int[size];
		top=-1;
	}
	
	public void push(int key) {
		arr[++top] = key;
	}

	public int pop() {
		return arr[top--];
	}

	public int getPeekN(int index) {
		return arr[index];
	}

	public int getPeek() {
		return arr[top];
	}

	public boolean isFull() {
		return (top==maxSize) ? true : false;
	}

	public boolean isEmpty() {
		return (top==-1) ? true : false;
	}

	public void display() {
		for(int i=0;i<=top;i++) {
			System.out.println(arr[i]);
		}
	}
}

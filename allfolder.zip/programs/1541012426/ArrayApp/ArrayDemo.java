import java.util.Scanner;
public class ArrayDemo {
	
	private int arr[];
	private int maxSize;
	private int nElements;

	public int getSize() {
		return this.nElements;
	}
	
	public void insert(int value) {
		
		if(this.maxSize!=nElements) {
			this.arr[this.nElements]=value;
			this.nElements++;
		}
	}
	
	public void display() {
	
		for(int i=0;i<this.nElements;i++) {
			System.out.println("index " + i +"=" + this.arr[i]);
		}
	}
	
	public int find(int value) {
	
		int i;
		for(i=0;i<this.nElements;i++) {
			if(this.arr[i] == value)
				break;
		}
		return i;
	}
	
	public void delete(int value) {
	
		if(this.nElements != 0) {
			int index = this.find(value);
			for(int i=index;i<this.nElements-1;i++) {
				this.arr[i] = this.arr[i+1];
			}
			this.nElements--;
		}
	}

	public ArrayDemo(int maxSize) {

		arr = new int[maxSize];
		this.maxSize = maxSize;
	}
	
	public void init() {
		
		Scanner sc =new Scanner(System.in);
		int choice = 1;
		while(choice != 0) {
			System.out.println("Enter value to insert");
			int i = sc.nextInt();
			insert(i);
			System.out.println("Press: 0. Exit\n1. insert" );
			choice = sc.nextInt();
		}
	}
	
	public int getMax() {
		
		int max=0;
		for(int i=0;i<nElements;i++) {
			
			if(this.arr[i] > max) {
				max = this.arr[i];
			}
		}
		
		return max;
	}
	
	public int removeMax() {
		
		int max = this.getMax();
		delete(max);
		return max;
	}

	public void noDups() {
		
		int nDuplicates = 0;
		for(int i=0;i<this.nElements;i++) {
			
			for(int j=i+1;j<this.nElements;j++) {

				if(this.arr[i]==this.arr[j]) {
					this.arr[j]=-1;
					nDuplicates++;
				}
			}
		}

		for(int i=0;i<nDuplicates;i++) {
			this.delete(-1);
		}
	}

	private void swap(int a, int b) {
		
		int temp = this.arr[a];
		this.arr[a] = this.arr[b];
		this.arr[b] = temp;
	}

	public void bubbleSort() {

		for(int i = this.nElements-1; i > 0; i--) {
			
			for(int j = 0;j < i; j++) {
				
				if(this.arr[j] > arr[j+1]) {
					swap(j,j+1);
				}
			}
		}
	}

	public void oddEvenBubbleSort() {
		
		for(int i = this.nElements-1;i>0;i--) {
			
			for(int j = 0; j < this.nElements-1; j += 2) {
				

				if(this.arr[j]>this.arr[j+1]) {
					this.swap(j,j+1);
				}
			}

			for(int j = 1; j < this.nElements-1; j += 2) {
				

				if(this.arr[j] > this.arr[j+1]) {
					this.swap(j,j+1);
				}
			}
		}
	}

	public void biDirectionalSort() {
		
		int outTop=this.nElements-1;
		int outBottom=0;
		while(outBottom<outTop) {
			
			for(int i=outBottom; i < outTop; i++) {
				
				if(arr[i] > arr[i+1]) {
					swap(i, i+1);
				}
			}
			outTop--;
			for(int i=outTop; i > outBottom; i--) {
				
				if(arr[i-1] > arr[i]) {
					swap(i-1, i);
				}
			}
			outBottom++;
		}
	}

	public void selectionSort() {
		
		int index=0;
		for(int i=0;i<nElements;i++) {
			
			index=getIndex(i);
			swap(index,i);
		}
	}

	private int getIndex(int i) {
		
		int min = i;
		for(int j = i+1 ;j<nElements;j++) {
			
			if(arr[j]<arr[min]) {
				min = j;
			}
		}
		return min;
	}

	public void insertionSort() {

		int k=0;
		for(int i=1;i<nElements;i++) {
		
			int temp=arr[i];
			int j=i;
			while(j>0 && arr[j-1]>=temp) {
				if(arr[j-1]==temp && temp!=-1) {
					temp=-1;
					k++;
				}
				arr[j]=arr[j-1];
				j--;
			}
			arr[j]=temp;
		}
		resizeArray(k);
	}

	public float getMedian() {
		
		if(nElements%2==0)
			return (float)(arr[(nElements/2)-1]+arr[(nElements/2)])/2;
		return arr[nElements/2];
	}

	private void resizeArray(int i) {
	
		int k=i;
		for(int j=0;j<nElements;j++) {
			if(i>=nElements)
				break;
			arr[j]=arr[i];
			i++;
		}
		nElements=nElements-k;
	}

	public void noDupsSort() {

		int shiftAmount=0;
		int total=nElements;
		long curNum=0;
		for(int i=0;i<total;i++) {
			if(arr[i]==curNum) {
				shiftAmount++;
				nElements--;
			} else {
				curNum=arr[i];
				arr[i-shiftAmount]=arr[i];
			}
		}
	}

	public void noDupsSorted() {
		
		int k=1;
		int j=1;
		for(int i=0;i<nElements;i++) {
			
			while(arr[i] == arr[j] && j<nElements) {
				j++;
			}
			if(j==nElements) {
				break;
			}
			arr[k]=arr[j];
			k++;	
			i=j;		
		}
		nElements=k;
	}
}

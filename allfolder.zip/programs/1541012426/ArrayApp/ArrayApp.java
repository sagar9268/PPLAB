import java.util.Scanner;

class ArrayApp {
	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);
		int choice =1 ;
		System.out.println("Enter array size:");
		int value=0;
		value = sc.nextInt(); 
		ArrayDemo arrDemo= new ArrayDemo(value);
		arrDemo.init();

		while(choice != 0) {
			System.out.println("Enter Choice");
			System.out.println("\n0.Exit\n1.Display\n2.Get Max\n3.Delete\n4.Insert\n5.Delete Max\n6.Sort array\n7.No dup\n8.Bubble sort\n9.OddEvenBubbleSort\n10.BiDirectional\n11.SelectionSort\n12.InsertionSort\n13.NoDupsSortedArray\n14.Median");
		choice = sc.nextInt();
			switch(choice) {

				case 1 : arrDemo.display();
					break;

				case 2 : System.out.println(arrDemo.getMax());
					break;

				case 3 :System.out.println("Enter value to delete");
					value = sc.nextInt(); 
					arrDemo.delete(value);
					break;

				case 4 :System.out.println("Enter value to insert");
					value = sc.nextInt();
					arrDemo.insert(value);
					break;

				case 5 :arrDemo.removeMax();
					break;

				case 6: ArrayDemo arrSort = new ArrayDemo(value);
					while(arrDemo.getMax()!=0) {
						arrSort.insert(arrDemo.removeMax());
					}	
					arrSort.display();	
					break;

				case 7: arrDemo.noDups();
					arrDemo.display();
					break;

				case 8: arrDemo.bubbleSort();
					arrDemo.display();
					break;

				case 9: arrDemo.oddEvenBubbleSort();
					arrDemo.display();
					break;

				case 10: arrDemo.biDirectionalSort();
					arrDemo.display();
					break;
		
				case 11: arrDemo.selectionSort();
					arrDemo.display();
					break;

				case 12: arrDemo.insertionSort();
					arrDemo.display();
					break;

				case 13: arrDemo.noDupsSort();
					//arrDemo.display();
					break;

				case 14: float median= arrDemo.getMedian();
					System.out.println("Median="+median);
					break;
				default : return;
			}
		}
	}
}

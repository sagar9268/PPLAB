class Frequency {
	
}

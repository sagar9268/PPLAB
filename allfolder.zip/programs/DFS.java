import java.util.*;

class DFS {

	int V;
	LinkedList<Integer> adj[];
	
	DFS(int v) {
		V=v;
		adj = new LinkedList[V];
		for(int i=0;i<v;i++)
			adj[i] = new LinkedList<Integer>();
	}
	
	void addEdge(int v, int w) {
		adj[v].add(w);
	}
	
	void DFSUtil(int src, boolean visited[]) {
	
		visited[src]=true;
		System.out.println(src + " ");
		Iterator<Integer> i = adj[src].listIterator();
		while(i.hasNext()) {
			int n = i.next();
			if(!visited[n]) {
				DFSUtil(n,visited);
			}
		}
	}
	
	void DFSTraverse(int src) {
		
		boolean visited[] = new boolean[V];
		DFSUtil(src, visited);
	}
	
	public static void main(String args[]) {
		DFS g = new DFS(4);
	 
		g.addEdge(0, 1);
		g.addEdge(0, 2);
		g.addEdge(1, 2);
		g.addEdge(2, 0);
		g.addEdge(2, 3);
		g.addEdge(3, 3);
	 
		System.out.println("Following is Depth First Traversal "+
		                   "(starting from vertex 2)");
	 
		g.DFSTraverse(2);
    }
}

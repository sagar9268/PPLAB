import java.util.*;
class DetectCyclic {

	int v;
	LinkedList<Integer> adj[];
	boolean recStack[];
	
	DetectCyclic(int v) {
		this.v = v;
		adj = new LinkedList[v];
		recStack = new boolean[v];
		for(int i=0;i<v;i++)
			adj[i] = new LinkedList();
	}
	
	void addEdge(int v, int w) {
		adj[v].add(w);
	}
	
	boolean detectCycle(int src, boolean visited[]) {
	
		visited[src]= true;
		recStack[src]=true;
		Iterator<Integer> i = adj[src].listIterator();
		while(i.hasNext()) {
			int n =i.next();
			if(!visited[n] && detectCycle(n, visited)) 
				return true;
			else if(recStack[n])
				return true;
		}
		recStack[src]=false;
		return false;
	}
	
	boolean detect() {
		boolean visited[] = new boolean[v];
		for(int i= 0;i<v;i++) {
			if(!visited[i])
				if(detectCycle(i, visited))
					return true;
		}	
		return false;
	}
	
	public static void main(String args[]) {
	
		DetectCyclic g = new DetectCyclic(4);
		g.addEdge(0, 1);
		g.addEdge(0, 2);
		g.addEdge(1, 2);
		g.addEdge(2, 0);
		g.addEdge(2, 3);
		g.addEdge(3, 3);
		if(g.detect())
			System.out.println("Cycle");
		else
			System.out.println("Not a cycle");
	}
}

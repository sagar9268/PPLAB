import java.util.*;

class Stackx
{
  private int maxsize;
  private int top;
  private char[] stackarray;
  
  Stackx(int m)
  {
     maxsize=m;
     stackarray= new char[maxsize];
     top=-1;
  }
  
  public void push(char ele)
  {
    stackarray[++top]=ele;
  }
  
  public char pop()
  {
    return stackarray[top--];
  }
  
  public char peek()
  {
    return stackarray[top];
  }
  
  public boolean isEmpty()
  {
    return (top==-1);
  }
  
  public boolean isFul()
  {
    return (top==maxsize-1);
  }
  
}

class BracketChecker
{ 
 private String input;

 
 BracketChecker(String inp)
 { 
    input=inp;
 }

 public void check()
 {
    int size=input.length();
    Stackx s1=new Stackx(size);
    
    for(int i=0;i<size;i++)
      {
         
         char ch=input.charAt(i);
         
       switch(ch)
        {
         case '{':
         case '[':
         case '(': 
            s1.push(ch);
            break;
         case '}':
         case ']':
         case ')': 
             if(!s1.isEmpty())
             {
               char chx=s1.pop();
               if((chx== '{' && ch!= '}')||(chx== '[' && ch!= ']')||(chx== '(' && ch!= ')'))
                 System.out.println("Error "+ch+" at "+ i);                 
              }
             else
                 System.out.println("Error "+ch+" at "+ i);                 
             
             break;      
         default:
              break;
        }
       }
        if(!s1.isEmpty())
           System.out.println("Missing right delimeter ");                 
       
  } 
}

class BracketApp
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a String containing delimeters");
	String inp=sc.next();
        BracketChecker b1=new BracketChecker(inp);
        b1.check();
        System.out.println();     
   }
}


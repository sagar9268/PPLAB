import java.util.*;

class Stackx
{
  private int maxsize;
  private int top;
  private int[] stackarray;
  
  Stackx(int m)
  {
     maxsize=m;
     stackarray= new int[maxsize];
     top=-1;
  }
  
  public void push(int ele)
  {
    stackarray[++top]=ele;
  }
  
  public int pop()
  {
    return stackarray[top--];
  }
  
  public int peek()
  {
    return stackarray[top];
  }
  
  public boolean isEmpty()
  {
    return (top==-1);
  }
  
  public boolean isFul()
  {
    return (top==maxsize-1);
  }
  
}

class StackApp
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of the Stack");
	int s=sc.nextInt();
	Stackx s1=new Stackx(s);
	System.out.println("Enter "+s+" Elements to be inserted im the stack");
	for(int i=0;i<s;i++)
	 s1.push(sc.nextInt());
	System.out.println("Elements of the Stack are "); 
	while(!s1.isEmpty() )
	 { 
	  int ele=s1.pop();
 	  System.out.println(ele+" ");
	 }
   }
}


import java.util.*;

class Stackx
{
  private int maxsize;
  private int top;
  private char[] stackarray;
  
  Stackx(int m)
  {
     maxsize=m;
     stackarray= new char[maxsize];
     top=-1;
  }
  
  public void push(char ele)
  {
    stackarray[++top]=ele;
  }
  
  public char pop()
  {
    return stackarray[top--];
  }
  
  public char peek()
  {
    return stackarray[top];
  }
  
  public boolean isEmpty()
  {
    return (top==-1);
  }
  
  public boolean isFul()
  {
    return (top==maxsize-1);
  }
  
}

class Reverser
{ 
 private String input;
 private String output;
 
 Reverser(String inp)
 { 
    input=inp;
 }

 public String doRev()
 {
    int size=input.length();
    Stackx s1=new Stackx(size);
    
    for(int i=0;i<size;i++)
      s1.push(input.charAt(i));
     
   output="";
   while(!s1.isEmpty())
   {
     char ch=s1.pop();
     output=output+ch;
   }
   return output;
 }
}
class StackRevApp
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a Word");
	String inp=sc.next();
        Reverser r1=new Reverser(inp);
        System.out.println("Reverse of the input String is \n"+ r1.doRev());
   }
}


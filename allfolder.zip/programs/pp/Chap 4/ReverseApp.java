import java.util.*;

class StackX
{
   private int maxsize;
   private char[] stackarray;
   private int top;

   public StackX(int size)
   {
      maxsize=size;
      stackarray=new char[maxsize];
      top=-1;
   }

   public void push(char x)
   {
     stackarray[++top]=x;
   }   

   public char pop()
   {
     return stackarray[top--];
   }   

   public char peek()
   {
     return stackarray[top];
   }   

   public boolean isEmpty()
   {
     return (top==-1);
   }   

   public boolean isFull()
   {
     return (top==maxsize-1);
   }   
 
}
class Reverser
{
  private String input;
  private String output;

  public Reverser(String in)
  {
    input=in;
  }

  public String dorev()
  {
   int size=input.length();
   StackX S=new StackX(size);

   for(int i=0;i<size;i++)
   {
    char ch=input.charAt(i);
    S.push(ch);
   }
    output="";
   while(!S.isEmpty())
   {
    output=output+S.pop();
   }
   
   return output;
  }
}
class ReverseApp
{
  public static void main(String args[])
  {
     Scanner sc= new Scanner(System.in);
     System.out.println("Enter the String to be reversed");
     String in=sc.next();
     Reverser R=new Reverser(in);
     
     System.out.println("After reversing the String \n"+ R.dorev());
  }     
}
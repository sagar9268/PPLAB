import java.util.*;

class StackX
{
   private int maxsize;
   private int[] stackarray;
   private int top;

   public StackX(int size)
   {
      maxsize=size;
      stackarray=new int[maxsize];
      top=-1;
   }

   public void push(int x)
   {
     stackarray[++top]=x;
   }   

   public int pop()
   {
     return stackarray[top--];
   }   

   public int peek()
   {
     return stackarray[top];
   }   

   public boolean isEmpty()
   {
     return (top==-1);
   }   

   public boolean isFull()
   {
     return (top==maxsize-1);
   }   
 
}

class StackApp
{
  public static void main(String args[])
  {
     Scanner sc= new Scanner(System.in);
     System.out.println("Enter the maximum size of the stack");
     int size=sc.nextInt();
     StackX S=new StackX(size);
     System.out.println("Enter the elements of the stack");
     for(int i=0; i<size;i++)
       S.push(sc.nextInt());
     System.out.println("The elements of the stack are ");
     while(!S.isEmpty())
     {
       System.out.print(S.pop()+" ");     
     }
       System.out.println();     
  }     
}
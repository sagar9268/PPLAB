import java.util.*;
class QueueX
{
    private int maxsize;
    private int[] arr;
    private int front;
    private int rear;
    private int n;

    public QueueX(int s)
    {
      maxsize=s;
      arr=new int[maxsize];
      front=0;
      rear=-1;
      n=0;
    }

    public void insert(int j)
    {
      if(rear==maxsize-1)
         rear=-1;
      arr[++rear]=j;
      n++;
    }

    public int remove()
    {
      int temp=arr[front++];
      if(front==maxsize)   
         front=0;
      n--;
      return temp;
    }

    public int peekfront()
    {

      return arr[front];
    }

    public boolean isEmpty()
    {
       return (n==0);
    }

    public boolean isFull()
    {
       return (n==maxsize);
    }

    public int size()
    {
       return n;
    }
}

class QueueApp
{
   public static void main(String[] args)
    {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of the Queue");
 	int size=sc.nextInt();
	QueueX Q=new QueueX(size);
 
        System.out.println("Enter the elements ");
        for(int i=0;i<size;i++)
	  Q.insert(sc.nextInt());
         
        while(!Q.isEmpty())
          System.out.print(Q.remove()+" ");
 	System.out.println();
     }
}


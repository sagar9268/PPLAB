import java.util.*;
class Dequeuex
{ 
   private int maxsize;
   private int front;
   private int rear;
   private int[] arr;
   private int n;
   
   Dequeuex(int s)
   {
     maxsize=s;
     arr=new int[maxsize];
     rear=-1;
     front=0;
     n=0;
   }
   
   public void insertleft(int ele)
   {
     if(!isFull())
       {
         front--;
         if(front<0)
           front=maxsize-1;
         arr[front]=ele;
         n++;
       }
     else
       System.out.println("Queue is full");
   }
   
   public void insertright(int ele)
   {
     if(!isFull())
       {
        rear++;
        if(rear>=maxsize)
           rear=0;
        arr[rear]=ele;
        n++;
       }
     else
       System.out.println("Queue is full");
    }

   public int removeright()
   { 
     if(!isEmpty())
      {
        int ele=arr[rear];
         rear--;
        if(rear<0)
          rear=maxsize-1;
        n--;
       return ele;
       }
     else 
       {
         System.out.println("The queue us empty");
         return -1;
       }
   }

   
   public int removeleft()
   { 
     if(!isEmpty())
      {
        int ele=arr[front];
         front++;
        if(front>=maxsize)
          front=0;
        n--;
       return ele;
       }
     else 
       {
         System.out.println("The queue us empty");
         return -1;
       }
   }

   public int peek()
   {
   return arr[front];   
   }
   
   public boolean isEmpty()
   {
     return (n==0);
   }
    
   public boolean isFull()
   {
     return (n==maxsize);
   } 
   
   public int size()
   {
    return n;
   }
 }
 
class DequeApp
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	//System.out.println("Enter the size of the Queue");
	//int s=sc.nextInt();
	Dequeuex q1=new Dequeuex(10);
	//System.out.println("Enter "+s+" Elements to be inserted im the stack");
//	for(int i=0;i<s;i++)
	 q1.insertleft(50);
	 q1.insertleft(40);
	 q1.insertleft(30);
	 q1.insertleft(20);

	 q1.insertleft(10);
	 q1.insertright(60);
	 q1.insertright(70);
	 q1.insertright(80);
	 q1.insertright(90);
	 q1.insertright(100);


	System.out.println("Elements of the Queue are "); 
	while(!q1.isEmpty() )
	 { 
	  int ele=q1.removeleft();
 	  System.out.print(ele+" ");
	 }
   }
}
  
  
   
      

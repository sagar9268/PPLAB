import java.util.*;

class StackX
{
   private int maxsize;
   private char[] stackarray;
   private int top;

   public StackX(int size)
   {
      maxsize=size;
      stackarray=new char[maxsize];
      top=-1;
   }

   public void push(char x)
   {
     stackarray[++top]=x;
   }   

   public char pop()
   {
     return stackarray[top--];
   }   

   public char peek()
   {
     return stackarray[top];
   }   

   public boolean isEmpty()
   {
     return (top==-1);
   }   

   public boolean isFull()
   {
     return (top==maxsize-1);
   }   
 
}

class Bracket
{
  private String input;
  

  public Bracket(String in)
  {
    input=in;
  }

  public void check()
  {
   int size=input.length();
   StackX S=new StackX(size);

   for(int i=0;i<size;i++)
   {
    char ch=input.charAt(i);
    switch(ch)
     {
        case '{':
        case '[':
        case '(':
          S.push(ch);
	   break;
        case '}':
        case ']':
        case ')':
          if(S.isEmpty())
	    {
 	 	char chx=S.pop();
	        if( (ch=='}' && chx!='{') || (ch==']' && chx!='[') || (ch=='0' && chx!='('))
		System.out.println("Error "+ch+" at "+i);
  	    }
 	  else
	        System.out.println("Error "+ch+" at "+i);
          break;
        default:
            break;
     }
   }
   if(!S.isEmpty())
	System.out.println("Error missing right delimeter");
  }
}
class BracketApp
{
  public static void main(String args[])
  {
     Scanner sc= new Scanner(System.in);
     System.out.println("Enter the String ");
     String in=sc.next();
     Bracket B=new Bracket(in);
     
     B.check();
  }     
}
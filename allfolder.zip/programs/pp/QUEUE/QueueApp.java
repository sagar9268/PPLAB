import java.util.*;
class Queuex
{ 
   private int maxsize;
   private int front;
   private int rear;
   private int[] arr;
   private int n;
   
   Queuex(int s)
   {
     maxsize=s;
     arr=new int[maxsize];
     rear=-1;
     front=0;
     n=0;
   }
   
   public void insert(int ele)
   {
     if(rear==maxsize)
        rear=-1;
     arr[++rear]=ele;
     n++;
   }
   
   public int remove()
   { 
     int ele=arr[front++];
     if(front==maxsize)
       front=0;
     n--;
     return ele;
   }
   
   public int peek()
   {
   return arr[front];   
   }
   
   public boolean isEmpty()
   {
     return (n==0);
   }
    
   public boolean isFull()
   {
     return (n==maxsize);
   } 
   
   public int size()
   {
    return n;
   }
 }
 
class QueueApp
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of the Queue");
	int s=sc.nextInt();
	Queuex q1=new Queuex(s);
	System.out.println("Enter "+s+" Elements to be inserted im the stack");
	for(int i=0;i<s;i++)
	 q1.insert(sc.nextInt());
	System.out.println("Elements of the Queue are "); 
	while(!q1.isEmpty() )
	 { 
	  int ele=q1.remove();
 	  System.out.print(ele+" ");
	 }
   }
}
  
  
   
      

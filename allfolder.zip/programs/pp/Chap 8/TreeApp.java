class node
{
	int data;
        node left;
        node right;
    public node(int d)
    {
      data=d;
      left=null;
      right=null;
    }
  

}

class TreeApp
{
   public static void main(String args[])
   {
     




   }

}
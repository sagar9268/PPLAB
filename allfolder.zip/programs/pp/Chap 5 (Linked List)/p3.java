import java.util.*;
class Link
{
	public int data;
	public Link next;

 	public Link(int d)
	{
	  data=d;
	}

	public void displaynode()
	{
	  System.out.println(data);
	}
}

class CircularLinkedList
{
	private Link first;

	public CircularLinkedList()
	{
	  first=null;
	}

	public Boolean isEmpty()
	{
	  return (first==null);
	}

	public void InsertFirst(int d)
	{
	  Link node=new Link(d);
	  if(first==null)
            {
               first=node;
	       node.next=first;
	     }
          else
            {
               Link temp=first;
	       do
		{
		  temp=temp.next;
		}while(temp.next!=first);
		node.next=first;
	        temp.next=node;
	     }

	
	}


	public Link DeleteFirst()
	{
	  Link temp=first;
	    do
	     {
	      temp=temp.next;
	     }while(temp.next!=first);
		temp.next=first.next;
	        temp=first;
		first=first.next;
	
	   return temp;	
	}

	public void display()
	{
	  Link curr=first;
 	  do
           {		
            curr.displaynode();
	    curr=curr.next;
           }while(curr!=first);

	}
 	
	public Link search(int key)
	{
	   Link curr=first;
           while(curr.data!=key)
	   {
             if(curr.next==null)
		return null;
             else
               curr=curr.next;
           }
           return curr;
	}

	public Link delete(int key)
	{
	   Link curr=first;
	   Link prev=first;
	 
           while(curr.data!=key)
	   {
             if(curr.next==null)
		return null;
             else
               {
		 prev=curr;
                 curr=curr.next;
  	        }
                
           }

	  if(curr==first)
 	    first=first.next;
          else
           prev.next=curr.next;

           return curr;
	}

}


class p3
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	CircularLinkedList L= new CircularLinkedList();
        
        L.InsertFirst(10);
        L.InsertFirst(20);
        L.InsertFirst(30);
        L.InsertFirst(40);
        L.InsertFirst(50);
        System.out.println("The Linked List is");
        L.display();
        System.out.println("Deleting first element "+ L.DeleteFirst().data);
        System.out.println("The Linked List after deleting one element ");
        L.display();



}
}


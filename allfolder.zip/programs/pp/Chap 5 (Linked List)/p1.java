import java.util.*;
class Link
{
	public int data;
        public Link next;
	
	public Link(int d)
	{
	  data=d;
	}

	public void displaynode()
	{
	 System.out.println(data);
	}
}


class SortedQueueList
{
	private Link first;
	private Link last;	

	public SortedQueueList()
	{
	  first=null;
	  last=null;
	}
     
	public boolean isEmpty()
	{
	  return (first==null);
	}

	public void InsertLast(int d)
	{
	   Link newLink=new Link(d);
	   if(isEmpty())
	      first=newLink;
	   else
	      last.next=newLink;
   	   last=newLink;
	}

	public void insert(int key) 
        {
           Link newLink = new Link(key); 
           Link prev = null; 
	   Link curr = first;
 	   while(curr!= null && key > curr.data)
	   {
	      prev= curr;
	      curr=curr.next; 
	   }
           if(prev==null) 
	      first = newLink; 
           else 
              prev.next = newLink; 
	      newLink.next = curr; 
	}
 
	public int DeleteFirst()
	{
	   int temp=first.data;
	   if(first.next==null)
	      last=null;
	   first=first.next;
   	   return temp;
	}
	

	public void display()
	{
	   Link curr=first;
	   while(curr!=null)
	   {
		curr.displaynode();
		curr=curr.next;
	   }
	System.out.println("");
 	}
}	 
class LinkQueue
{
	private SortedQueueList List;
   
        public LinkQueue()
	{
	   List=new SortedQueueList();
	}
	
	public boolean isEmpty()
	{
	   return List.isEmpty();
	}

	public void insert(int k)
	{
	   List.insert(k);
	}
	
	public int delete()
	{
	   return List.DeleteFirst();
	}

	public void displayQueue()
	{
	   System.out.println("Queue (front-->rear):");
	   List.display();
	}
}

class p1
{
public static void main(String args[])
{
   Scanner sc=new Scanner(System.in);
   LinkQueue Queue=new LinkQueue();
   
   Queue.insert(50);
   Queue.insert(70);
   Queue.insert(10);
   Queue.insert(30);
   Queue.insert(40);

   Queue.insert(90);
   Queue.insert(60);
   Queue.insert(20);

   Queue.displayQueue();

   Queue.delete();
   Queue.displayQueue();
}

}
import java.util.*;

class Link
{
	public int data;
	public Link next;

	public Link(int d)
	{
	  data=d;
	}
	
	public void displaynode()
	{
	  System.out.println(data);
	}
} 

class LinkedList
{ 	
	private Link first;
	private Link last;
	
	public LinkedList()
	{
	  first=null;
	}

	public void InsertFirst(int d)
	{
	   Link node=new Link(d);
	   if(first==null)
	     {
	        first=node;
	        node.next=first;
                last=node;
              }
           else
             {
              node.next=first;
              first=node;
              last.next=first;  
              }	   
	}
	
	public Link DeleteFirst()
	{
	   Link temp=first;
 	   first=first.next;
	   last.next=first;
           return temp;
	}

	public void display()
	{
	  Link curr=first;
	  do
	  {
	     curr.displaynode();
	     curr=curr.next;
	  } while(curr!=first);
	}

	public Link search(int key)
	{
	   Link curr=first;
	   while(curr.data!=key)
	   {
	     if(curr==null)
		return null;
	     else
	        curr=curr.next;
           }
           return curr;
	}

	public Link delete(int key)
	{
	   Link curr=first;
	   Link prev=first;
	   while(curr.data!=key)
	   {
	     if(curr==null)
		return null;
	     else
	        {
	          prev=curr;
		  curr=curr.next;
		} 
           }
	    if(curr==first)
	       first=first.next;
	     else
	       prev.next=curr.next;       

	    return curr;
	}

}

class LinkedListApp
{
  public static void  main(String args[])
  {
	 Scanner sc=new Scanner(System.in);
	 LinkedList L=new LinkedList();
	 System.out.println("Enter the data of the node");
	 L.InsertFirst(sc.nextInt());
	 System.out.println("Enter the data of the node");
	 L.InsertFirst(sc.nextInt());
	 System.out.println("Enter the data of the node");
	 L.InsertFirst(sc.nextInt());
	 System.out.println("Enter the data of the node");
	 L.InsertFirst(sc.nextInt());
	
	 System.out.println("The Linked you created is ");
 	 L.display();
	 
	 System.out.println("Deleting the first node of the Linked List "+ L.DeleteFirst().data);
	 L.display();

	 
  }
}
	
	
		
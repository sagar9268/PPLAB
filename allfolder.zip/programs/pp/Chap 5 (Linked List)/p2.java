class ddnode
{
	int data;
	ddnode flink;
	ddnode blink;

	public ddnode(int d)
	{
		data=d;
		flink=null;
		blink=null;
	}
	void display()
	{
		System.out.println(data);
	}
}
class doublelinked
{
	ddnode start;
	ddnode end;
	public doublelinked()
	{
		start=null;
		end=null;
	}
	void insert_at_beg(int x)
	{
		ddnode newn= new ddnode(x);
		if(start==null)
		{
			start=newn;
			end=newn;
		}
		else
		{
			newn.flink=start;
			start.blink=newn;
			start=newn;
		}
	}

	void insert_at_end(int x)
	{
		ddnode newn=new ddnode(x);

		if(start==null)
		{
			start=newn;
			end=newn;
		}
		else
		{	
			newn.blink=end;
			end.flink=newn;
			end=newn;
		}
	}
	void delete_at_beg()
	{
		if(start==null)
		{
			System.out.println("underflow");
		}
		else if(start==end)
		{
			start=null;
			end=null;
		}
		else
		{
			start=start.flink;
			start.blink=null;
		}
	}
	void delete_at_end()
	{
		if(start==null)
		{
			System.out.println("underflow");
		}
		else if(start==end)
		{
			start=null;
			end=null;
		}
		else
		{
			end=end.blink;
			end.flink=null;
		}
	}
	void forwarddisplay()
	{
		System.out.println("list(first---->last):");
		ddnode p=start;
		while(p!=null)
		{
			p.display();
			p=p.flink;
		}
	}
	void backwarddisplay()
	{
		System.out.println("list(last--->first):");
		ddnode p=end;
		while(p!=null)
		{
			p.display();
			p=p.blink;
		}
	}

}
class Deque
{
    doublelinked deq;

     public Deque()
     {
	deq=new doublelinked();
     }

     public void insertleft(int x)
     {
        deq.insert_at_beg(x);
     }

     public void insertright(int x)
     {
        deq.insert_at_end(x);
     }

     public void deleteleft()
     {
        deq.delete_at_beg();
     }

     public void deleteright()
     {
        deq.delete_at_end();
     }

    public void displaydequeleft()
    {
       deq.forwarddisplay();
    }
    
    public void displaydequeright()
    {
       deq.backwarddisplay();
    }
}


class p2
{
  public static void main(String args[])
{
 Deque d1=new Deque();
 d1.insertleft(80);
 d1.insertleft(70);
 d1.insertleft(60);
 d1.insertleft(50);
 d1.insertleft(40);
 d1.insertleft(30);
 d1.insertleft(20);
 d1.insertleft(10);
 d1.insertleft(110);
 d1.insertright(90);
 d1.insertright(100);
 System.out.println("Forward Display");
 d1.displaydequeleft();

 System.out.println("Backward Display");
 d1.displaydequeright();

 d1.deleteleft();
 d1.deleteright();


 System.out.println("Forward Display");
 d1.displaydequeleft();

 System.out.println("Backward Display");
 d1.displaydequeright();


}

}

		

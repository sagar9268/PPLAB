import java.util.*;
class LevelOrder {

	Node root;
	LevelOrder() {
		root = null;
	}
	
	public static void main(String args[]) {
	
		Scanner sc = new Scanner(System.in);
		LevelOrder obj = new LevelOrder();
		
		int T =sc.nextInt();
		for(int i=0;i<T;i++) {
		
			int n = sc.nextInt();
			for(int j=0;i<n;i++) {
				int k = sc.nextInt();
				obj.insert(k);
			}
			obj.traverse();
		}	
	}
	
	void insert(int key) {
	
		if(root==null) {
			root = new Node(key);
			return;
		}
		Node temp = root;
		Queue<Node> q  = new LinkedList<Node>();
		q.add(temp);
		while(q.size()>0) {

			temp = q.peek();
			q.remove();
			if(temp.left==null) {
				temp.left = new Node(key);
				break;
			} else
				q.add(temp.left);
				
			if(temp.right==null) {
				temp.right = new Node(key);
				break;
			} else 
				q.add(temp.right);
		}
	}
	
	void traverse() {
	
		Queue<Node> q = new LinkedList<Node>();
		if(root==null)
			return;
		q.add(root);
		int maxSize = 0;
		int count =0;
		int level = 0;
		int i = 0;
		System.out.println();
		while(q.size()>0) {
		
			count = q.size();
			while(count>0) {
				count--;
				Node temp = q.peek();
				q.remove();
				if(temp.left!=null)
					q.add(temp.left);
				if(temp.right!=null)
					q.add(temp.right);
				System.out.print(" " + temp.data + " ");
			}
			i++;
			System.out.println();
		}
	}
}

class Node {

	Node left;
	Node right;
	int data;
	Node(int data) {
		this.data = data;
		left = null;
		right = null;
	}
}
	

import java.util.*;
class Link
{
	public int data;
	public Link next;

 	public Link(int d)
	{
	  data=d;
	}

	public void displaynode()
	{
	  System.out.println(data);
	}
}

class CircularLinkedList
{
	private Link curr;
        int no;

	public CircularLinkedList()
	{
	  curr=null;
	  no=0;
	}

	public Boolean isEmpty()
	{
	  return (curr==null);
	}

	public void insert(int d)
	{
	  Link node=new Link(d);
	  if(curr==null)
 	   {
	     curr=node;
	     node.next=curr;
           }
           else
 	   {
	     node.next=curr.next;
	     curr.next=node;
             curr=curr.next;
           }
          no++;
	}



	public void josephus(int n,int c,int s)
        {
         Link startpoint=search(s);  
         curr=startpoint;
         Link temp=null;
         Link prev=null;
         System.out.print("People eliminated are");
         while(curr.next!=curr)
         {
	   for(int i=0;i<=c;i++)
           {
             prev=temp;
             temp=curr;
 	       curr=curr.next;
           }
          System.out.print("  "+temp.data);
	prev.next=temp.next;
         }
 	}  
        
        public Link search(int key)
	{
	   Link first=curr;
           while(first.data!=key)
	   {
               first=curr.next;
           }
           return first;
	}

       public void display()
	{
	  Link start=curr;
 	  for(int i=0;i<no;i++)		
            {
	    start.displaynode();
	    start=start.next;
           }
         System.out.println();
	}
}


class p5
{
   public static void main(String args[])
   {
	Scanner sc=new Scanner(System.in);
	CircularLinkedList L= new CircularLinkedList();
        System.out.println("Enter the number of people in the circle");
        int n=sc.nextInt();
        System.out.println("Enter the start point");
        int s=sc.nextInt();
        System.out.println("Enter the coutn off");
        int c=sc.nextInt();
	for(int i=0;i<n;i++)
         L.insert(i+1);
	L.display();
      L.josephus(n,c,s);



}
}

